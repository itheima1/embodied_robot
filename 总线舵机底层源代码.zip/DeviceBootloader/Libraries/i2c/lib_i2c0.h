#ifndef __LIB_I2C_0_H__
#define __LIB_I2C_0_H__


#include "I2C_config.h"

#if USE_LIB_I2C_0


void lib_i2c0_init();
void lib_i2c0_loop();

uint8_t lib_i2c0_write_sync(uint8_t addr, uint8_t reg, uint8_t* data, uint16_t len);
uint8_t lib_i2c0_read_sync(uint8_t addr, uint8_t reg, uint8_t* data, uint16_t len);

#if I2C0_ENABLE_ASYNC
uint8_t lib_i2c0_write_async(uint8_t addr, uint8_t reg, uint8_t* data, uint16_t len, I2C_RW_Callback cb);
uint8_t lib_i2c0_read_async(uint8_t addr, uint8_t reg, uint16_t len, I2C_RW_Callback cb);
#endif


#if I2C0_IRQ_ENABLE
uint8_t lib_i2c0_irq_write(I2C_IRQ_Data_t dat);
uint8_t lib_i2c0_irq_read(I2C_IRQ_Data_t dat);
#endif




#endif
#endif