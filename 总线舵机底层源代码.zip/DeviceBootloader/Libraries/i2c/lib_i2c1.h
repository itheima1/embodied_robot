#ifndef __LIB_I2C_1_H__
#define __LIB_I2C_1_H__


#include "I2C_config.h"

#if USE_LIB_I2C_1


void lib_i2c1_init();
void lib_i2c1_loop();

uint8_t lib_i2c1_write_sync(uint8_t addr, uint8_t reg, uint8_t* data, uint16_t len);
uint8_t lib_i2c1_write2_sync(uint8_t addr, uint8_t reg, uint8_t* data, uint8_t offset, uint16_t len);
uint8_t lib_i2c1_read_sync(uint8_t addr, uint8_t reg, uint8_t* data, uint16_t len);

#if I2C1_ENABLE_ASYNC
uint8_t lib_i2c1_write_async(uint8_t addr, uint8_t reg, uint8_t* data, uint16_t len, I2C_RW_Callback cb);
uint8_t lib_i2c1_read_async(uint8_t addr, uint8_t reg, uint16_t len, I2C_RW_Callback cb);
#endif


#if I2C1_IRQ_ENABLE
uint8_t lib_i2c1_irq_write(I2C_IRQ_Data_t dat);
uint8_t lib_i2c1_irq_read(I2C_IRQ_Data_t dat);
#endif




#endif
#endif