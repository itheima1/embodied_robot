#ifndef __I2C_CONFIG_H__
#define __I2C_CONFIG_H__

#include "../gpio/lib_gpio.h"


#define USE_LIB_I2C_0	0
#define USE_LIB_I2C_1	0

/** I2C PIN Table
/////////////////////////////////////////
//|-------|-----|-----------|-----------|
//| I2C 0 |	SCL	|	PA9		|	AF4		|
//| 	  |		|-----------|-----------|
//| 	  |		|	PB6		|	AF1		|
//| 	  |		|-----------|-----------|
//| 	  |		|	PB8		|	AF1		|
//| 	  |		|-----------|-----------|
//| 	  |		|	PB10	|	AF1		|
//| 	  |		|-----------|-----------|
//| 	  |		|	PF0		|	AF1		|
//| 	  |		|-----------|-----------|
//| 	  |		|	PF6		|	AF1		|
//|       |-----|-----------|-----------|
//| 	  |	SDA	|	PA10	|	AF4		|
//| 	  |		|-----------|-----------|
//| 	  |		|	PB7		|	AF1		|
//| 	  |		|-----------|-----------|
//| 	  |		|	PB9		|	AF1		|
//| 	  |		|-----------|-----------|
//| 	  |		|	PB11	|	AF1		|
//| 	  |		|-----------|-----------|
//| 	  |		|	PF1		|	AF1		|
//| 	  |		|-----------|-----------|
//| 	  |		|	PF7		|	AF1		|
//|-------|-----|-----------|-----------|
//|///////|//////////////////////////////
//|-------|-----|-----------|-----------|
//|	I2C 1 |	SCL |	PA0		|	AF4		|
//| 	  |		|-----------|-----------|
//|       |		|	PA11	|	AF5		|
//| 	  |		|-----------|-----------|
//|       |		|	PB10	|	AF1		|
//| 	  |		|-----------|-----------|
//|       |		|	PB13	|	AF5		|
//| 	  |		|-----------|-----------|
//|       |		|	PF6		|	AF1		|
//|       |-----|-----------|-----------|
//|       |	SDA	|	PA1		|	AF4		|
//| 	  |		|-----------|-----------|
//|       |		|	PA12	|	AF5		|
//| 	  |		|-----------|-----------|
//|       |		|	PB11	|	AF1		|
//| 	  |		|-----------|-----------|
//|       |		|	PB14	|	AF5		|
//| 	  |		|-----------|-----------|
//|       |		|	PF7		|	AF1		|
//|-------|-----|-----------|-----------|
/////////////////////////////////////////
**/


///////////////////// I2C 0 ////////////////
#if USE_LIB_I2C_0

#define I2C0_SOFT				0
#define I2C0_SPEED				400000
#define I2C0_ENABLE_ASYNC		1

#if I2C0_ENABLE_ASYNC
#define I2C0_ASYNC_MAX_LEN		16
#endif

#define I2C0_SCL_RCU			RCU_GPIOB
#define I2C0_SCL_PORT			GPIOB
#define I2C0_SCL_PIN			GPIO_PIN_6
#define I2C0_SCL_AF				GPIO_AF_1

#define I2C0_SDA_RCU			RCU_GPIOB
#define I2C0_SDA_PORT			GPIOB
#define I2C0_SDA_PIN			GPIO_PIN_7
#define I2C0_SDA_AF				GPIO_AF_1

#if I2C0_SOFT == 0
#define I2C0_IRQ_ENABLE			0
#if	I2C0_IRQ_ENABLE
#define I2C0_EV_IRQn_NVIC		3
#define I2C0_ER_IRQn_NVIC		3
#endif
#endif

#endif


///////////////////// I2C 1 ////////////////
#if USE_LIB_I2C_1

#define I2C1_SOFT				0
#define I2C1_SPEED				400000
#define I2C1_ENABLE_ASYNC		1

#if I2C1_ENABLE_ASYNC
#define I2C1_ASYNC_MAX_LEN		16
#endif

#define I2C1_SCL_RCU			RCU_GPIOA
#define I2C1_SCL_PORT			GPIOA
#define I2C1_SCL_PIN			GPIO_PIN_0
#define I2C1_SCL_AF				GPIO_AF_4

#define I2C1_SDA_RCU			RCU_GPIOA
#define I2C1_SDA_PORT			GPIOA
#define I2C1_SDA_PIN			GPIO_PIN_1
#define I2C1_SDA_AF				GPIO_AF_4

#if I2C1_SOFT == 0
#define I2C1_IRQ_ENABLE			0
#if	I2C1_IRQ_ENABLE
#define I2C1_EV_IRQn_NVIC		3
#define I2C1_ER_IRQn_NVIC		3
#endif
#endif


#endif



/////////////////////////////////////////////////////////////////////////////////////////
typedef void (*I2C_RW_Callback)(uint8_t err, uint8_t* data, uint16_t len);


typedef struct {
	uint8_t rwaddr;
	uint8_t reg;
	uint8_t* data;
	uint16_t len;
	I2C_RW_Callback cb;
} I2C_RWData_t;


/////////////////////////////////////////////////////////////////////////////////////////
static inline uint8_t I2C_wait(uint32_t i2cx, uint32_t flag) {
    uint16_t TIMEOUT = 50000;
    uint16_t cnt = 0;

    while(!i2c_flag_get(i2cx, flag)) {
        cnt++;
        if(cnt > TIMEOUT) return 1;
    }
    return 0;
}

static inline uint8_t I2C_waitn(uint32_t i2cx, uint32_t flag) {
    uint16_t TIMEOUT = 50000;
    uint16_t cnt = 0;

    while(i2c_flag_get(i2cx, flag)) {
        cnt++;
        if(cnt > TIMEOUT) return 1;
    }
	return 0;
}





#endif