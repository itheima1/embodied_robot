#ifndef __LIB_FMC_H__
#define __LIB_FMC_H__

#include "FMC_config.h"

#if USE_LIB_FMC

void lib_fmc_init();
void lib_fmc_deinit();


uint8_t lib_fmc_erase(uint32_t addr, uint32_t len);
uint8_t lib_fmc_write(uint32_t addr, uint8_t* dat, uint32_t len);
uint8_t lib_fmc_read(uint32_t addr, uint8_t *dat, uint32_t len);


#endif

#endif