#include "lib_fmc.h"
#if USE_LIB_FMC
#include <string.h>


void lib_fmc_init() {
}

void lib_fmc_deinit() {
}

uint8_t lib_fmc_write(uint32_t address, uint8_t* dat, uint32_t len) {
	/* unlock the flash program/erase controller */
    fmc_unlock();
	
    /* program flash */
	uint32_t i = 0;
    while(len > 0) {
		uint16_t data;
		
		if(len < 2) {
			data = (0x00 << 8) | dat[i];
			i += 1;
			len -= 1;
		} else {
			data = (dat[i + 1] << 8) | dat[i];
			i += 2;
			len -= 2;
		}
		fmc_halfword_program(address, data);
        address += 2U;
        fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_WPERR | FMC_FLAG_PGERR);
    }

    /* lock the main FMC after the program operation */
    fmc_lock();
	
	return 0;
}

uint8_t lib_fmc_read(uint32_t addr, uint8_t *dat, uint32_t len) {
	for(uint32_t i = 0; i < len; i++) {
		dat[i] = *((uint8_t *) addr);
		addr++;
	}
	return 0;
}

uint8_t lib_fmc_erase(uint32_t addr, uint32_t len) {
    // �����ַ�ͳ��ȵ�ҳ��߽�
    uint32_t aligned_addr = (addr / LIB_FMC_PAGE_SIZE) * LIB_FMC_PAGE_SIZE;
    uint32_t aligned_len = ((addr + len + LIB_FMC_PAGE_SIZE - 1) / LIB_FMC_PAGE_SIZE) * LIB_FMC_PAGE_SIZE - aligned_addr;

    // ��������
    fmc_unlock();

    // ������й����־
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_WPERR | FMC_FLAG_PGERR);

    // ����ѭ��
    while (aligned_len > 0) {
        fmc_page_erase(aligned_addr);

        // ����Ƿ��д���
        if (fmc_flag_get(FMC_FLAG_WPERR) || fmc_flag_get(FMC_FLAG_PGERR)) {
            fmc_lock(); // ��������
            return 1;   // ���ش�����
        }

        // ���µ�ַ�ͳ���
        aligned_addr += LIB_FMC_PAGE_SIZE;
        aligned_len -= LIB_FMC_PAGE_SIZE;
    }

    // ������й����־
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_WPERR | FMC_FLAG_PGERR);

    // ��������
    fmc_lock();
	
    return 0; // ���سɹ�
}


#endif