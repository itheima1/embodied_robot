#ifndef __FMC_CONFIG_H__
#define __FMC_CONFIG_H__


#include "../gpio/lib_gpio.h"



#define USE_LIB_FMC		1



#define LIB_FMC_BASE_ADDR	0x08000000
#define	LIB_FMC_PAGE_SIZE	0x0400			// 1k
#define	LIB_FMC_OB_CNT		4


#define LIB_FMC_WP_DISABLE_PAGE		60


#endif