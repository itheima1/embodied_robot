#include "lib_usart0.h"

#if USE_LIB_USART_0
#include <string.h>
#include <stdio.h>
#include "../common/circular_queue.h"

#define __USARTx_TX_RCU		USART0_TX_RCU
#define __USARTx_TX_PORT	USART0_TX_PORT
#define __USARTx_TX_PIN		USART0_TX_PIN
#define __USARTx_TX_AF		USART0_TX_AF
#define __USARTx_RX_RCU		USART0_RX_RCU
#define __USARTx_RX_PORT	USART0_RX_PORT
#define __USARTx_RX_PIN		USART0_RX_PIN
#define __USARTx_RX_AF		USART0_RX_AF

#define __USARTx_RCU			RCU_USART0
#define __USARTx				USART0
#define __USARTx_IRQ			USART0_IRQn

#define __USARTx_PRINT		0

#define __USARTx_TX_LEN				USART0_TX_LEN
#define __USARTx_RX_LEN				USART0_RX_LEN
#define __USARTx_RECV_NVIC_IRQ 		USART0_RECV_NVIC_IRQ
#define __USARTx_PARAM_BAUDRATE		USART0_PARAM_BAUDRATE
#define __USARTx_PARAM_PARITY		USART0_PARAM_PARITY
#define __USARTx_PARAM_WORD_LEN		USART0_PARAM_WORD_LEN
#define __USARTx_PARAM_STOP_BIT		USART0_PARAM_STOP_BIT
#define __USARTx_PARAM_DATA_FIRST	USART0_PARAM_DATA_FIRST

#define	__USARTx_ENABLE_SEND		USART0_ENABLE_SEND
#define	__USARTx_ENABLE_RECV		USART0_ENABLE_RECV
#define __USARTx_ENABLE_DMA_SEND	USART0_ENABLE_DMA_SEND
#define __USARTx_ENABLE_DMA_RECV	USART0_ENABLE_DMA_RECV
#define __USARTx_RECV_CALLBACK		USART0_RECV_CALLBACK

#define __USARTx_FUNC_INIT			lib_usart0_init
#define __USARTx_FUNC_DEINIT		lib_usart0_deinit
#define __USARTx_FUNC_LOOP			lib_usart0_loop
#define __USARTx_FUNC_SEND_BYTE		lib_usart0_send_byte
#define __USARTx_FUNC_SEND_DATA		lib_usart0_send_data
#define __USARTx_FUNC_SEND_STRING	lib_usart0_send_string
#define __USARTx_FUNC_RX_CB			lib_usart0_on_recv


#if __USARTx_ENABLE_DMA_SEND
#define __USARTx_DMA_TX				USART0_DMA_TX_CHN
#endif
#if __USARTx_ENABLE_DMA_RECV
#define __USARTx_DMA_RX				USART0_DMA_RX_CHN
#endif

#define __USARTx_IRQHandler			USART0_IRQHandler


static CQ_Queue tx_queue;
static CQ_Queue rx_queue;

static uint8_t state = 0;

#define IS_RX_IDLE()	((state & 0x01) == 0)
#define SET_RX_BUSY()	(state |= 0x01)
#define SET_RX_IDLE()	(state &= ~0x01)

#define IS_TX_IDLE()	((state & 0x02) == 0)
#define SET_TX_BUSY()	(state |= 0x02)
#define SET_TX_IDLE()	(state &= ~0x02)


#if __USARTx_ENABLE_DMA_SEND
static void DMA_tx_config() {
    /********************* DMA TX ***************************/
    // ����ʱ��
    rcu_periph_clock_enable(RCU_DMA);
    // ����DMA
    dma_deinit(__USARTx_DMA_TX);
    // ��ʼ��dma
    dma_parameter_struct dps;
    dma_struct_para_init(&dps);
	
	///// ����
	dps.direction    = (uint8_t)DMA_MEMORY_TO_PERIPHERAL;
	///// src
	dps.memory_inc   = (uint8_t)DMA_MEMORY_INCREASE_ENABLE;
//	dps.memory_addr  = 0U;
//	dps.number       = 0U;
    dps.memory_width = DMA_MEMORY_WIDTH_8BIT;
	///// dst
	dps.periph_addr  = (uint32_t)(&USART_TDATA(__USARTx));
    dps.periph_width = DMA_PERIPHERAL_WIDTH_8BIT;
    dps.periph_inc   = (uint8_t)DMA_PERIPH_INCREASE_DISABLE;
    
    dps.priority     = (uint32_t)DMA_PRIORITY_HIGH;
	
	dma_init(__USARTx_DMA_TX, &dps);
}
#endif


#if __USARTx_ENABLE_DMA_RECV

static void DMA_rx_config() {
    /******************** DMA RX *******************/
    // ����DMA
    dma_deinit(__USARTx_DMA_RX);
    // ��ʼ��dma
    dma_parameter_struct dps;
    dma_struct_para_init(&dps);
	
	///// ����
	dps.direction    = (uint8_t)DMA_PERIPHERAL_TO_MEMORY;
	///// src
	dps.periph_addr  = (uint32_t)(&USART_RDATA(__USARTx));
    dps.periph_width = DMA_PERIPHERAL_WIDTH_8BIT;
    dps.periph_inc   = (uint8_t)DMA_PERIPH_INCREASE_DISABLE;
	
	///// dst
	dps.memory_inc   = (uint8_t)DMA_MEMORY_INCREASE_ENABLE;
	dps.memory_addr  = (uint32_t)recv_buff;
	dps.number       = __USARTx_RECV_LEN;
    dps.memory_width = DMA_MEMORY_WIDTH_8BIT;
    
    dps.priority     = (uint32_t)DMA_PRIORITY_HIGH;
	
	dma_init(__USARTx_DMA_RX, &dps);
	
	dma_channel_enable(__USARTx_DMA_RX);
}
#endif



void __USARTx_FUNC_INIT() {
	CQ_Init(&tx_queue, __USARTx_TX_LEN);
	CQ_Init(&rx_queue, __USARTx_RX_LEN);
	
    ////////// gpio config ///////////////
    lib_io_af_pp(__USARTx_TX_RCU, __USARTx_TX_PORT, __USARTx_TX_PIN, __USARTx_TX_AF);
    lib_io_af_pp(__USARTx_RX_RCU, __USARTx_RX_PORT, __USARTx_RX_PIN, __USARTx_RX_AF);

    ////////// usart config /////////////
    lib_usart_cfg(__USARTx_RCU, __USARTx, __USARTx_PARAM_BAUDRATE, __USARTx_PARAM_PARITY,
                  __USARTx_PARAM_WORD_LEN, __USARTx_PARAM_STOP_BIT, __USARTx_PARAM_DATA_FIRST);

#if __USARTx_ENABLE_SEND
	// ���͹�������
	usart_transmit_config(__USARTx, USART_TRANSMIT_ENABLE);
#endif

#if __USARTx_ENABLE_RECV
	// ���չ�������
	usart_receive_config(__USARTx, USART_RECEIVE_ENABLE);
	// �����ж�����
	nvic_irq_enable(__USARTx_IRQ, __USARTx_RECV_NVIC_IRQ);
	// usart int rbne
	usart_interrupt_enable(__USARTx, USART_INT_RBNE);
	usart_interrupt_enable(__USARTx, USART_INT_IDLE);
#endif

#if __USARTx_ENABLE_DMA_SEND
	// ����DMA���͹���
	usart_dma_transmit_config(__USARTx, USART_DENT_ENABLE);
	DMA_tx_config();
#endif

#if __USARTx_ENABLE_DMA_RECV
	// ����DMA���չ���
	usart_dma_receive_config(__USARTx, USART_DENR_ENABLE);
	DMA_rx_config();
#endif
	// ʹ�ܴ���
	usart_enable(__USARTx);
}


void __USARTx_FUNC_DEINIT() {
	CQ_Free(&tx_queue);
	CQ_Free(&rx_queue);
	
#if __USARTx_ENABLE_SEND
	usart_transmit_config(__USARTx, USART_TRANSMIT_DISABLE);
#endif
#if __USARTx_ENABLE_RECV
	// ���չ�������
	usart_receive_config(__USARTx, USART_RECEIVE_DISABLE);
	// �����ж�����
	nvic_irq_disable(__USARTx_IRQ);
	// usart int rbne
	usart_interrupt_disable(__USARTx, USART_INT_RBNE);
	usart_interrupt_disable(__USARTx, USART_INT_IDLE);
#endif

#if __USARTx_ENABLE_DMA_SEND
	// ����DMA���͹���
	usart_dma_transmit_config(__USARTx, USART_DENT_DISABLE);
#endif

#if __USARTx_ENABLE_DMA_RECV
	// ����DMA���չ���
	usart_dma_receive_config(__USARTx, USART_DENR_DISABLE);
#endif
	usart_disable(__USARTx);
}


#if __USARTx_ENABLE_DMA_SEND
static void USARTx_dma_send(uint8_t* data, uint32_t len) {
    if(data == 0 || len == 0) return;

    /******************** DMA send *******************/
    /* �ر�DMAͨ�� */
    dma_channel_disable(__USARTx_DMA_TX);
    /* ����DMA������ڴ��ַ�ʹ������ݴ�С */
    dma_memory_address_config(__USARTx_DMA_TX, (uint32_t)data);
    dma_transfer_number_config(__USARTx_DMA_TX, len);
    /* ʹ��DMAͨ�� */
    dma_channel_enable(__USARTx_DMA_TX);

    while(1) {
        if(dma_flag_get(__USARTx_DMA_TX, DMA_FLAG_FTF) != RESET) {
            /* ���DMA������ɱ�־ */
            dma_flag_clear(__USARTx_DMA_TX, DMA_FLAG_FTF);
            break;
        }
    }
}
#endif


void __USARTx_FUNC_SEND_BYTE(uint8_t data) {
	CQ_Enqueue(&tx_queue, data);
	
//#if __USARTx_ENABLE_SEND
//	if(IS_TX_IDLE()) {
//		uint16_t len = CQ_Size(&tx_queue);
//		if(len > 0) {
//			SET_TX_BUSY();
//			usart_interrupt_enable(__USARTx, USART_INT_TBE);
//		}
//	}
//#endif
}

void __USARTx_FUNC_SEND_DATA(uint8_t *data, uint16_t len) {
	CQ_EnqueueList(&tx_queue, data, len);

//#if __USARTx_ENABLE_SEND
//	if(IS_TX_IDLE()) {
//		uint16_t len = CQ_Size(&tx_queue);
//		if(len > 0) {
//			SET_TX_BUSY();
//			usart_interrupt_enable(__USARTx, USART_INT_TBE);
//		}
//	}
//#endif
}

//�����ַ���
void __USARTx_FUNC_SEND_STRING(char *data) {
    while(data && *data) {
        __USARTx_FUNC_SEND_BYTE((uint8_t)(*data));
        data++;
    }
}


#if __USARTx_ENABLE_RECV
void __USARTx_IRQHandler(void) {
	if(usart_interrupt_flag_get(__USARTx, USART_INT_FLAG_TBE) == SET) {
		uint8_t data;		
		if(CQ_Dequeue(&tx_queue, &data)) {			
			usart_data_transmit(__USARTx, data);
			
			if (!CQ_IsEmpty(&tx_queue)) {
                // ������в�Ϊ�գ��������÷����ж�
                usart_interrupt_enable(__USARTx, USART_INT_TBE);
            } else {
                // �������Ϊ�գ����÷����ж�
                usart_interrupt_disable(__USARTx, USART_INT_TBE);
                SET_TX_IDLE();
            }
			
		} else {
			SET_TX_IDLE();
			usart_interrupt_disable(__USARTx, USART_INT_TBE);
		}
	}
#if __USARTx_ENABLE_DMA_RECV
    if (usart_interrupt_flag_get(__USARTx, USART_INT_FLAG_IDLE) == SET) {
        //��ȡ������,��ջ�����
        usart_interrupt_flag_clear(__USARTx, USART_INT_FLAG_IDLE);
        recv_len = __USARTx_RECV_LEN - dma_transfer_number_get(__USARTx_DMA_RX);
		if(recv_len != 0 && recv_len < __USARTx_RECV_LEN)
        {
			recv_buff[recv_len] = '\0';
#if __USARTx_RECV_CALLBACK
            // ����ֹͣʱ���������е����ݣ������ڴ˴������������ݡ�TODO:
            lib_usart0_on_recv(recv_buff, recv_len);
#endif
			// �ر�DMA����ͨ��
			dma_channel_disable(__USARTx_DMA_RX);
            /// dma_flag_clear(__USARTx_DMA_RX, DMA_FLAG_FTF);
			dma_transfer_number_config(__USARTx_DMA_RX, __USARTx_RECV_LEN);
            dma_channel_enable(__USARTx_DMA_RX);
        } else {
            memset(recv_buff, 0, __USARTx_RECV_LEN);
        }
    }
#else
    if ((usart_interrupt_flag_get(__USARTx, USART_INT_FLAG_RBNE)) == SET) {
		SET_RX_BUSY();
		CQ_Enqueue(&rx_queue, (uint8_t)usart_data_receive(__USARTx));
		
//		LOG_DEBUG("RBNE\r\n");
    }
    if (usart_interrupt_flag_get(__USARTx, USART_INT_FLAG_IDLE) == SET) {
        //��ȡ������,��ջ�����
        usart_interrupt_flag_clear(__USARTx, USART_INT_FLAG_IDLE);
		
		SET_RX_IDLE();
    }
#endif
}
#endif


void __USARTx_FUNC_LOOP() {
#if __USARTx_RECV_CALLBACK
	if(IS_RX_IDLE()) {
		uint16_t len = CQ_Size(&rx_queue);
		if(len > 0) {
			uint8_t data[len + 1];
			data[len] = '\0';
			CQ_DequeueList(&rx_queue, data, len);
			
			__USARTx_FUNC_RX_CB(data, len);
		}
	}
#endif
#if __USARTx_ENABLE_SEND
	if(IS_TX_IDLE()) {
		uint16_t len = CQ_Size(&tx_queue);
		if(len > 0) {
			SET_TX_BUSY();
			usart_interrupt_enable(__USARTx, USART_INT_TBE);
		}
	}
#endif
}


#ifdef USE_USARTx_PRINT

#if USE_USARTx_PRINT == __USARTx_PRINT

int fputc(int ch, FILE *f) {
    __USARTx_FUNC_SEND_BYTE((uint8_t)ch);
    return ch;
}

#endif
#endif



#endif