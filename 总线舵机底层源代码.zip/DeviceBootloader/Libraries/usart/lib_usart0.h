#ifndef __LIB_USART_0_H__
#define __LIB_USART_0_H__


#include "Usart_config.h"


#if USE_LIB_USART_0

void lib_usart0_init();
void lib_usart0_deinit();
void lib_usart0_send_byte(uint8_t data);
void lib_usart0_send_data(uint8_t *data, uint16_t len);
void lib_usart0_send_string(char *data);

void lib_usart0_loop();

#if USART0_RECV_CALLBACK
extern void lib_usart0_on_recv(uint8_t *data, uint16_t len);
#endif	// USART0_RECV_CALLBACK


#endif // USE_LIB_USART_0


#endif //__LIB_USART_0_H__