#include "lib_usart1.h"

#if USE_LIB_USART_1
#include <string.h>
#include <stdio.h>
#include "../common/circular_queue.h"

#define __USARTx_TX_RCU		USART1_TX_RCU
#define __USARTx_TX_PORT	USART1_TX_PORT
#define __USARTx_TX_PIN		USART1_TX_PIN
#define __USARTx_TX_AF		USART1_TX_AF
#define __USARTx_RX_RCU		USART1_RX_RCU
#define __USARTx_RX_PORT	USART1_RX_PORT
#define __USARTx_RX_PIN		USART1_RX_PIN
#define __USARTx_RX_AF		USART1_RX_AF

#define __USARTx_RCU		RCU_USART1
#define __USARTx			USART1
#define __USARTx_IRQ		USART1_IRQn

#define __USARTx_PRINT		1

#define __USARTx_TX_LEN				USART1_TX_LEN
#define __USARTx_RX_LEN				USART1_RX_LEN
#define __USARTx_RECV_NVIC_IRQ 		USART1_RECV_NVIC_IRQ
#define __USARTx_PARAM_BAUDRATE		USART1_PARAM_BAUDRATE
#define __USARTx_PARAM_PARITY		USART1_PARAM_PARITY
#define __USARTx_PARAM_WORD_LEN		USART1_PARAM_WORD_LEN
#define __USARTx_PARAM_STOP_BIT		USART1_PARAM_STOP_BIT
#define __USARTx_PARAM_DATA_FIRST	USART1_PARAM_DATA_FIRST

#define	__USARTx_ENABLE_SEND		USART1_ENABLE_SEND
#define	__USARTx_ENABLE_RECV		USART1_ENABLE_RECV
#define __USARTx_ENABLE_DMA_SEND	USART1_ENABLE_DMA_SEND
#define __USARTx_ENABLE_DMA_RECV	USART1_ENABLE_DMA_RECV
#define __USARTx_RECV_CALLBACK		USART1_RECV_CALLBACK

#define __USARTx_FUNC_INIT			lib_usart1_init
#define __USARTx_FUNC_LOOP			lib_usart1_loop
#define __USARTx_FUNC_SEND_BYTE		lib_usart1_send_byte
#define __USARTx_FUNC_SEND_DATA		lib_usart1_send_data
#define __USARTx_FUNC_SEND_STRING	lib_usart1_send_string
#define __USARTx_FUNC_RX_CB			lib_usart1_on_recv


#if __USARTx_ENABLE_DMA_SEND
#define __USARTx_DMA_TX				USART0_DMA_TX_CHN
#endif
#if __USARTx_ENABLE_DMA_RECV
#define __USARTx_DMA_RX				USART0_DMA_RX_CHN
#endif

#define __USARTx_IRQHandler			USART1_IRQHandler


//static uint8_t	recv_buff[__USARTx_RECV_LEN];   // ���ջ�����
//static uint32_t recv_len = 0;

static uint8_t tx_buff[__USARTx_TX_LEN];
static QueueType_t tx_queue;

static uint8_t	rx_buff[__USARTx_RX_LEN];
static QueueType_t rx_queue;

static uint8_t state = 0;


#if __USARTx_ENABLE_DMA_SEND
static void DMA_tx_config() {
    /********************* DMA TX ***************************/
    // ����ʱ��
    rcu_periph_clock_enable(RCU_DMA);
    // ����DMA
    dma_deinit(__USARTx_DMA_TX);
    // ��ʼ��dma
    dma_parameter_struct dps;
    dma_struct_para_init(&dps);
	
	///// ����
	dps.direction    = (uint8_t)DMA_MEMORY_TO_PERIPHERAL;
	///// src
	dps.memory_inc   = (uint8_t)DMA_MEMORY_INCREASE_ENABLE;
//	dps.memory_addr  = 0U;
//	dps.number       = 0U;
    dps.memory_width = DMA_MEMORY_WIDTH_8BIT;
	///// dst
	dps.periph_addr  = (uint32_t)(&USART_TDATA(__USARTx));
    dps.periph_width = DMA_PERIPHERAL_WIDTH_8BIT;
    dps.periph_inc   = (uint8_t)DMA_PERIPH_INCREASE_DISABLE;
    
    dps.priority     = (uint32_t)DMA_PRIORITY_HIGH;
	
	dma_init(__USARTx_DMA_TX, &dps);
}
#endif


#if __USARTx_ENABLE_DMA_RECV

static void DMA_rx_config() {
    /******************** DMA RX *******************/
    // ����DMA
    dma_deinit(__USARTx_DMA_RX);
    // ��ʼ��dma
    dma_parameter_struct dps;
    dma_struct_para_init(&dps);
	
	///// ����
	dps.direction    = (uint8_t)DMA_PERIPHERAL_TO_MEMORY;
	///// src
	dps.periph_addr  = (uint32_t)(&USART_RDATA(__USARTx));
    dps.periph_width = DMA_PERIPHERAL_WIDTH_8BIT;
    dps.periph_inc   = (uint8_t)DMA_PERIPH_INCREASE_DISABLE;
	
	///// dst
	dps.memory_inc   = (uint8_t)DMA_MEMORY_INCREASE_ENABLE;
	dps.memory_addr  = (uint32_t)recv_buff;
	dps.number       = __USARTx_RECV_LEN;
    dps.memory_width = DMA_MEMORY_WIDTH_8BIT;
    
    dps.priority     = (uint32_t)DMA_PRIORITY_HIGH;
	
	dma_init(__USARTx_DMA_RX, &dps);
	
	dma_channel_enable(__USARTx_DMA_RX);
}
#endif



void __USARTx_FUNC_INIT() {
	queue_init(&tx_queue, tx_buff, __USARTx_TX_LEN);
	queue_init(&rx_queue, rx_buff, __USARTx_RX_LEN);
	
    ////////// gpio config ///////////////
    lib_io_af_pp(__USARTx_TX_RCU, __USARTx_TX_PORT, __USARTx_TX_PIN, __USARTx_TX_AF);
    lib_io_af_pp(__USARTx_RX_RCU, __USARTx_RX_PORT, __USARTx_RX_PIN, __USARTx_RX_AF);

    ////////// usart config /////////////
    lib_usart_cfg(__USARTx_RCU, __USARTx, __USARTx_PARAM_BAUDRATE, __USARTx_PARAM_PARITY,
                  __USARTx_PARAM_WORD_LEN, __USARTx_PARAM_STOP_BIT, __USARTx_PARAM_DATA_FIRST);

#if __USARTx_ENABLE_SEND
	// ���͹�������
	usart_transmit_config(__USARTx, USART_TRANSMIT_ENABLE);
#endif

#if __USARTx_ENABLE_RECV
	// ���չ�������
	usart_receive_config(__USARTx, USART_RECEIVE_ENABLE);
	// �����ж�����
	nvic_irq_enable(__USARTx_IRQ, __USARTx_RECV_NVIC_IRQ);
	// usart int rbne
	usart_interrupt_enable(__USARTx, USART_INT_RBNE);
	usart_interrupt_enable(__USARTx, USART_INT_IDLE);
#endif

#if __USARTx_ENABLE_DMA_SEND
	// ����DMA���͹���
	usart_dma_transmit_config(__USARTx, USART_DENT_ENABLE);
	DMA_tx_config();
#endif

#if __USARTx_ENABLE_DMA_RECV
	// ����DMA���չ���
	usart_dma_receive_config(__USARTx, USART_DENR_ENABLE);
	DMA_rx_config();
#endif
	// ʹ�ܴ���
	usart_enable(__USARTx);
}


#if __USARTx_ENABLE_DMA_SEND
static void USARTx_dma_send(uint8_t* data, uint32_t len) {
    if(data == 0 || len == 0) return;

    /******************** DMA send *******************/
    /* �ر�DMAͨ�� */
    dma_channel_disable(__USARTx_DMA_TX);
    /* ����DMA������ڴ��ַ�ʹ������ݴ�С */
    dma_memory_address_config(__USARTx_DMA_TX, (uint32_t)data);
    dma_transfer_number_config(__USARTx_DMA_TX, len);
    /* ʹ��DMAͨ�� */
    dma_channel_enable(__USARTx_DMA_TX);

    while(1) {
        if(dma_flag_get(__USARTx_DMA_TX, DMA_FLAG_FTF) != RESET) {
            /* ���DMA������ɱ�־ */
            dma_flag_clear(__USARTx_DMA_TX, DMA_FLAG_FTF);
            break;
        }
    }
}
#endif


void __USARTx_FUNC_SEND_BYTE(uint8_t data) {
	queue_push(&tx_queue, data);
}

void __USARTx_FUNC_SEND_DATA(uint8_t *data, uint16_t len) {
	queue_push_array(&tx_queue, data, len);
}

//�����ַ���
void __USARTx_FUNC_SEND_STRING(char *data) {
    while(data && *data) {
        __USARTx_FUNC_SEND_BYTE((uint8_t)(*data));
        data++;
    }
}


#if __USARTx_ENABLE_RECV
void __USARTx_IRQHandler(void) {
	if(usart_interrupt_flag_get(__USARTx, USART_INT_FLAG_TBE) == SET) {
		
		uint8_t data;
		if(queue_pop(&tx_queue, &data) == QUEUE_OK) {
			state |= 0x02;
			usart_data_transmit(__USARTx, data);
		} else {
			usart_interrupt_disable(__USARTx, USART_INT_TBE);
			state &= ~0x02;
		}
	}
#if __USARTx_ENABLE_DMA_RECV
    if (usart_interrupt_flag_get(__USARTx, USART_INT_FLAG_IDLE) == SET) {
        //��ȡ������,��ջ�����
        usart_interrupt_flag_clear(__USARTx, USART_INT_FLAG_IDLE);
        recv_len = __USARTx_RECV_LEN - dma_transfer_number_get(__USARTx_DMA_RX);
		if(recv_len != 0 && recv_len < __USARTx_RECV_LEN)
        {
			recv_buff[recv_len] = '\0';
#if __USARTx_RECV_CALLBACK
            // ����ֹͣʱ���������е����ݣ������ڴ˴������������ݡ�TODO:
            lib_usart0_on_recv(recv_buff, recv_len);
#endif
			// �ر�DMA����ͨ��
			dma_channel_disable(__USARTx_DMA_RX);
            /// dma_flag_clear(__USARTx_DMA_RX, DMA_FLAG_FTF);
			dma_transfer_number_config(__USARTx_DMA_RX, __USARTx_RECV_LEN);
            dma_channel_enable(__USARTx_DMA_RX);
        } else {
            memset(recv_buff, 0, __USARTx_RECV_LEN);
        }
    }
#else
    if ((usart_interrupt_flag_get(__USARTx, USART_INT_FLAG_RBNE)) == SET) {
		state |= 0x01;
		queue_push(&rx_queue, (uint8_t)usart_data_receive(__USARTx));
    }
    if (usart_interrupt_flag_get(__USARTx, USART_INT_FLAG_IDLE) == SET) {
        //��ȡ������,��ջ�����
        usart_interrupt_flag_clear(__USARTx, USART_INT_FLAG_IDLE);
		// queue_push(&rx_queue, '\0');
		
		state &= ~0x01;
#if __USARTx_RECV_CALLBACK
#endif
    }
#endif
}
#endif


void __USARTx_FUNC_LOOP() {
#if __USARTx_RECV_CALLBACK
	if((state & 0x01) == 0) {
		uint16_t len = queue_data_count(&rx_queue);
		if(len > 0) {
			uint8_t data[len + 1];
			data[len] = '\0';
			queue_pop_array(&rx_queue, data, len);
			
			__USARTx_FUNC_RX_CB(data, len);
		}
	}
#endif
#if __USARTx_ENABLE_SEND
	if((state & 0x02) == 0) {
		uint16_t len = queue_data_count(&tx_queue);
		if(len > 0) {
			usart_interrupt_enable(__USARTx, USART_INT_TBE);
		}
	}
#endif
}


#ifdef USE_USARTx_PRINT

#if USE_USARTx_PRINT == __USARTx_PRINT

int fputc(int ch, FILE *f) {
    __USARTx_FUNC_SEND_BYTE((uint8_t)ch);
    return ch;
}

#endif
#endif



#endif