#ifndef __LIB_USART_H__
#define __LIB_USART_H__


#include "Usart_config.h"

#if USE_LIB_USART_0
#include "lib_usart0.h"
#endif

#if USE_LIB_USART_1
#include "lib_usart1.h"
#endif

void lib_usart_init();

void lib_usart_loop();

void lib_usart_deinit();

#endif