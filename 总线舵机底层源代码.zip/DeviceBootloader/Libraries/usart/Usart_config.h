#ifndef __USART_CONFIG_H__
#define __USART_CONFIG_H__

#include "../gpio/lib_gpio.h"


#define USE_LIB_USART_0		1
#define USE_LIB_USART_1		0


#define USE_USARTx_PRINT		0
//#define USE_USARTx_PRINT		1

/** USART PIN Table
/////////////////////////////////////////////////////
//|-------|-----|-----------|-----------|-----------|
//|Usart0 |	TX	|	PA2		|	AF1		|			|
//| 	  |		|-----------|-----------|			|
//| 	  |		|	PA9		|	AF1		|	CH1		|
//| 	  |		|-----------|-----------|			|
//| 	  |		|	PA14	|	AF1		|	CH3		|
//| 	  |		|-----------|-----------|			|
//| 	  |		|	PB6		|	AF0		|			|
//|       |-----|-----------|-----------|-----------|
//| 	  |	RX	|	PA3		|	AF1		|			|
//| 	  |		|-----------|-----------|			|
//| 	  |		|	PA10	|	AF1		|	CH2		|
//| 	  |		|-----------|-----------|			|
//| 	  |		|	PA15	|	AF1		|	CH4		|
//| 	  |		|-----------|-----------|			|
//| 	  |		|	PB7		|	AF0		|			|
//|-------|-----|-----------|-----------|-----------|
//|///////|//////////////////////////////////////////
//|-------|-----|-----------|-----------|-----------|
//|Usart1 |	TX	|	PA2		|	AF1		|			|
//| 	  |		|-----------|-----------|	CH3		|
//|       |		|	PA14	|	AF1		|			|
//|       |-----|-----------|-----------|-----------|
//|       |	RX	|	PA3		|	AF1		|			|
//| 	  |		|-----------|-----------|	CH4		|
//|       |		|	PA15	|	AF1		|			|
//|-------|-----|-----------|-----------|-----------|
/////////////////////////////////////////////////////
**/

////////////////////////////////////////////////////////////////
/////////////////////////////// Usart 0 ////////////////////////
////////////////////////////////////////////////////////////////
#if USE_LIB_USART_0

#define USART0_ENABLE_SEND			1
#define USART0_ENABLE_RECV			1
#define USART0_TX_LEN				512
#define USART0_RX_LEN				512
#define USART0_RECV_NVIC_IRQ		1, 0
#define USART0_RECV_CALLBACK		1
#define USART0_ENABLE_DMA_SEND		0
#define USART0_ENABLE_DMA_RECV		0


//////// TX GPIO config
#define USART0_TX_RCU					RCU_GPIOA
#define USART0_TX_PORT					GPIOA
#define USART0_TX_PIN					GPIO_PIN_9
#define USART0_TX_AF					GPIO_AF_1

//////// RX GPIO config
#define USART0_RX_RCU					RCU_GPIOA
#define USART0_RX_PORT					GPIOA
#define USART0_RX_PIN					GPIO_PIN_10
#define USART0_RX_AF					GPIO_AF_1

#if USART0_ENABLE_DMA_SEND
#define USART0_DMA_TX_CHN		DMA_CH1
#endif
#if USART0_ENABLE_DMA_RECV
#define USART0_DMA_RX_CHN 		DMA_CH2
#endif

// param config
#define USART0_PARAM_BAUDRATE			230400
#define USART0_PARAM_PARITY				USART_PM_NONE
#define USART0_PARAM_WORD_LEN			USART_WL_8BIT
#define USART0_PARAM_STOP_BIT			USART_STB_1BIT
#define USART0_PARAM_DATA_FIRST			USART_MSBF_LSB



#endif	// USE_LIB_USART_0



////////////////////////////////////////////////////////////////
/////////////////////////////// Usart 1 ////////////////////////
////////////////////////////////////////////////////////////////
#if USE_LIB_USART_1

#define USART1_ENABLE_SEND			1
#define USART1_ENABLE_RECV			1
#define USART1_TX_LEN				256
#define USART1_RX_LEN				256
#define USART1_RECV_NVIC_IRQ		2, 2
#define USART1_RECV_CALLBACK		1
#define USART1_ENABLE_DMA_SEND		0
#define USART1_ENABLE_DMA_RECV		0


//////// TX GPIO config
#define USART1_TX_RCU					RCU_GPIOA
#define USART1_TX_PORT					GPIOA
#define USART1_TX_PIN					GPIO_PIN_2
#define USART1_TX_AF					GPIO_AF_1

//////// RX GPIO config
#define USART1_RX_RCU					RCU_GPIOA
#define USART1_RX_PORT					GPIOA
#define USART1_RX_PIN					GPIO_PIN_3
#define USART1_RX_AF					GPIO_AF_1

#if USART1_ENABLE_DMA_SEND
#define USART1_DMA_TX_CHN		DMA_CH1
#endif
#if USART1_ENABLE_DMA_RECV
#define USART1_DMA_RX_CHN 		DMA_CH2
#endif

// param config
#define USART1_PARAM_BAUDRATE			115200
#define USART1_PARAM_PARITY				USART_PM_NONE
#define USART1_PARAM_WORD_LEN			USART_WL_8BIT
#define USART1_PARAM_STOP_BIT			USART_STB_1BIT
#define USART1_PARAM_DATA_FIRST			USART_MSBF_LSB

#endif	// USE_LIB_USART_1
























////////////////////////////////////  auto cfg /////////////////////////////////////////

static inline void lib_usart_cfg(rcu_periph_enum rcu, uint32_t usartx, uint32_t baudrate, uint32_t parity,
                                 uint32_t word_len, uint32_t stop_bit, uint32_t data_first) {
    // ����ʱ��
    rcu_periph_clock_enable(rcu);
    // USART��λ
    usart_deinit(usartx);
    usart_baudrate_set(usartx, baudrate);// ������
    usart_parity_config(usartx, parity);// У��λ
    usart_word_length_set(usartx, word_len);// ����λ��
    usart_stop_bit_set(usartx, stop_bit);// ֹͣλ
    usart_data_first_config(usartx, data_first);// �ȷ��͸�λ���ǵ�λ
}




#endif  // __USART_CONFIG_H__