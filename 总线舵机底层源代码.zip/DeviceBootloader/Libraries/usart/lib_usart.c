#include "lib_usart.h"



void lib_usart_init() {
#if USE_LIB_USART_0
	lib_usart0_init();
#endif

#if USE_LIB_USART_1
	lib_usart1_init();
#endif
}

void lib_usart_loop() {
#if USE_LIB_USART_0
	lib_usart0_loop();
#endif

#if USE_LIB_USART_1
	lib_usart1_loop();
#endif
}

void lib_usart_deinit() {
#if USE_LIB_USART_0
	lib_usart0_deinit();
#endif

#if USE_LIB_USART_1
	lib_usart1_deinit();
#endif
}