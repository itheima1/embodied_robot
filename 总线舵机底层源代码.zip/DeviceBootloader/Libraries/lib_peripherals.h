#ifndef __LIB_PERIPHERALS_H__
#define __LIB_PERIPHERALS_H__

#include "usart/lib_usart.h"
#include "i2c/lib_i2c.h"
#include "spi/lib_spi.h"
#include "timer/lib_timer.h"
#include "adc/lib_adc.h"
#include "fmc/lib_fmc.h"
#include "common/circular_queue.h"

void lib_peripherals_init();
void lib_peripherals_loop();

void lib_peripherals_deinit();


#endif