#ifndef __LIB_GPIO_H__
#define __LIB_GPIO_H__

#include "gd32f3x0.h"
#include "gd32f3x0_gpio.h"


static inline void lib_io_od_pu(uint32_t rcu, uint32_t port, uint32_t pin) {
    rcu_periph_clock_enable(rcu);
    gpio_mode_set(port, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, pin);
    gpio_output_options_set(port, GPIO_OTYPE_OD, GPIO_OSPEED_50MHZ, pin);
}

static inline void lib_io_pp(uint32_t rcu, uint32_t port, uint32_t pin) {
	rcu_periph_clock_enable(rcu);
    gpio_mode_set(port, GPIO_MODE_OUTPUT, GPIO_PUPD_NONE, pin);
    gpio_output_options_set(port, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, pin);
}

static inline void lib_io_pp_pu(uint32_t rcu, uint32_t port, uint32_t pin) {
	rcu_periph_clock_enable(rcu);
    gpio_mode_set(port, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, pin);
    gpio_output_options_set(port, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, pin);
}

static inline void lib_io_pp_pd(uint32_t rcu, uint32_t port, uint32_t pin) {
	rcu_periph_clock_enable(rcu);
    gpio_mode_set(port, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLDOWN, pin);
    gpio_output_options_set(port, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, pin);
}

static inline void lib_io_af_od(uint32_t rcu, uint32_t port, uint32_t pin, uint32_t af) {
    rcu_periph_clock_enable(rcu);
    gpio_af_set(port, af, pin);
    gpio_mode_set(port, GPIO_MODE_AF, GPIO_PUPD_NONE, pin);
    gpio_output_options_set(port, GPIO_OTYPE_OD, GPIO_OSPEED_50MHZ, pin);
}

static inline void lib_io_af_od_pu(uint32_t rcu, uint32_t port, uint32_t pin, uint32_t af) {
    rcu_periph_clock_enable(rcu);
    gpio_af_set(port, af, pin);
    gpio_mode_set(port, GPIO_MODE_AF, GPIO_PUPD_PULLUP, pin);
    gpio_output_options_set(port, GPIO_OTYPE_OD, GPIO_OSPEED_50MHZ, pin);
}


static inline void lib_io_af_pp(uint32_t rcu, uint32_t port, uint32_t pin, uint32_t af) {
	rcu_periph_clock_enable(rcu);
    gpio_mode_set(port, GPIO_MODE_AF, GPIO_PUPD_NONE, pin);
    gpio_output_options_set(port, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, pin);
    gpio_af_set(port, af, pin);
}

static inline void lib_io_analog(uint32_t rcu, uint32_t port, uint32_t pin) {
    rcu_periph_clock_enable(rcu);
    gpio_mode_set(port, GPIO_MODE_ANALOG, GPIO_PUPD_PULLDOWN, pin);
}

static inline void lib_io_write(uint32_t port, uint32_t pin, uint8_t val) {
	gpio_bit_write(port, pin, val);
}

static inline void lib_io_toggle(uint32_t port, uint32_t pin) {
	gpio_bit_toggle(port, pin);
}

#endif