#include "lib_peripherals.h"


void lib_peripherals_init() {
#if USE_LIB_USART_0 || USE_LIB_USART_1
	lib_usart_init();
#endif
#if USE_LIB_TIMER_0 || USE_LIB_TIMER_2 || USE_LIB_TIMER_5 || USE_LIB_TIMER_13 || USE_LIB_TIMER_14 || USE_LIB_TIMER_15 || USE_LIB_TIMER_16
	lib_timer_init();
#endif
#if USE_LIB_I2C_0 || USE_LIB_I2C_1
	lib_i2c_init();
#endif	
#if USE_LIB_SPI_0 || USE_LIB_SPI_1
	lib_spi_init();
#endif
#if USE_LIB_ADC
	lib_adc_init();
#endif
#if USE_LIB_FMC
	lib_fmc_init();
#endif
}

void lib_peripherals_loop() {
#if USE_LIB_USART_0 || USE_LIB_USART_1
	lib_usart_loop();
#endif
}

void lib_peripherals_deinit() {
#if USE_LIB_USART_0 || USE_LIB_USART_1
	lib_usart_deinit();
#endif
#if USE_LIB_TIMER_0 || USE_LIB_TIMER_2 || USE_LIB_TIMER_5 || USE_LIB_TIMER_13 || USE_LIB_TIMER_14 || USE_LIB_TIMER_15 || USE_LIB_TIMER_16
	lib_timer_deinit();
#endif
#if USE_LIB_I2C_0 || USE_LIB_I2C_1
	lib_i2c_deinit();
#endif	
#if USE_LIB_SPI_0 || USE_LIB_SPI_1
	lib_spi_deinit();
#endif
#if USE_LIB_ADC
	lib_adc_deinit();
#endif
#if USE_LIB_FMC
	lib_fmc_deinit();
#endif
}

