#include "lib_timer.h"


void lib_timer_init() {
#if USE_LIB_TIMER_0
	lib_timer0_init();
#endif

#if USE_LIB_TIMER_2
	lib_timer2_init();
#endif

#if USE_LIB_TIMER_5
	lib_timer5_init();
#endif

#if USE_LIB_TIMER_13
	lib_timer13_init();
#endif
}

void lib_timer_deinit() {
#if USE_LIB_TIMER_0
	lib_timer0_deinit();
#endif

#if USE_LIB_TIMER_2
	lib_timer2_deinit();
#endif

#if USE_LIB_TIMER_5
	lib_timer5_deinit();
#endif

#if USE_LIB_TIMER_13
	lib_timer13_deinit();
#endif	
}
