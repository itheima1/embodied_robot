#include "lib_timer5.h"


#if USE_LIB_TIMER_5

#define __TIMERx				TIMER5
#define __TIMERx_RCU			RCU_TIMER5
#define __TIMERx_IRQn			TIMER5_DAC_IRQn
#define __TIMERx_NVIC			TIMER5_NVIC
#define __TIMERx_IRQ_FUNC		TIMER5_DAC_IRQHandler

#define __TIMERx_PRESCALER	 	TIMER5_PRESCALER
#define	__TIMERx_FREQ 			TIMER5_FREQ

#define __TIMERx_INT_CALLBACK	TIMER5_INT_CALLBACK

#define	__TIMERx_INIT			lib_timer5_init
#define	__TIMERx_DEINIT			lib_timer5_deinit
#define __TIMERx_ON_INT			lib_timer5_on_interrupt
#define __TIMERx_UPDATE_PERIOD	lib_timer5_update_period

static uint16_t period = 0;
void __TIMERx_INIT() {

    /*************** Timer Config *******************/
    /// rcu
    rcu_periph_clock_enable(__TIMERx_RCU);
    timer_deinit(__TIMERx);
    /// timer init
    __TIMERx_UPDATE_PERIOD(__TIMERx_PRESCALER, __TIMERx_FREQ);
	
	/******************* INT config *******************/
	nvic_irq_enable(__TIMERx_IRQn, __TIMERx_NVIC);
	timer_interrupt_flag_clear(__TIMERx, TIMER_INT_FLAG_UP);
    timer_interrupt_enable(__TIMERx, TIMER_INT_UP);

    // ʹ��timer
    timer_enable(__TIMERx);
}

void __TIMERx_DEINIT() {
	nvic_irq_disable(__TIMERx_IRQn);
	timer_disable(__TIMERx);
}

void __TIMERx_UPDATE_PERIOD(uint16_t psc, uint32_t freq) {
    period = (SystemCoreClock / (freq * psc));
    /// timer init
    timer_parameter_struct tps;
    timer_struct_para_init(&tps);		// Ĭ��ֵ
    tps.prescaler = psc - 1;				// ��Ƶ
    tps.period = period - 1;				// ����
    timer_init(__TIMERx, &tps);
}

#if __TIMERx_INT_CALLBACK
void __TIMERx_IRQ_FUNC(void) {
    if(SET == timer_interrupt_flag_get(__TIMERx, TIMER_INT_UP)) {
		//����жϱ�־λ
		timer_interrupt_flag_clear(__TIMERx, TIMER_INT_FLAG_UP);
		__TIMERx_ON_INT();
	}
}

#endif

#endif