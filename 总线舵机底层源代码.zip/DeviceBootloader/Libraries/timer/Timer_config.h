#ifndef __TIMER_CONFIG_H___
#define __TIMER_CONFIG_H___

#include "../gpio/lib_gpio.h"


// 0,2,5,13..16

#define	USE_LIB_TIMER_0		0
#define	USE_LIB_TIMER_2		0
#define	USE_LIB_TIMER_5		1
#define	USE_LIB_TIMER_13	0
#define	USE_LIB_TIMER_14	0
#define	USE_LIB_TIMER_15	0
#define	USE_LIB_TIMER_16	0


/*****************************************/
/************* TIMER5 Config *************/
/*****************************************/
#if USE_LIB_TIMER_5

//��Ƶ���������� (PRESCALER * FREQ �������(��Ƶ/65536))
#define TIMER5_PRESCALER		10
#define TIMER5_FREQ				1000
#define TIMER5_NVIC				0, 0

#define TIMER5_INT_CALLBACK		1

#endif


/*****************************************/
/************* TIMER13 Config ************/
/*****************************************/
#if USE_LIB_TIMER_13

#define USE_LIB_TIMER13_CH0	1

//��Ƶ���������� (PRESCALER * FREQ �������(��Ƶ/65536))
#define TIMER13_PRESCALER			10
#define TIMER13_FREQ					500

/********** Timer10 CH0 *********/
///// PA7,PF9
#if USE_LIB_TIMER13_CH0
#define TIMER13_CH0_GPIO_RCU		RCU_GPIOA
#define TIMER13_CH0_GPIO_PORT		GPIOA
#define TIMER13_CH0_GPIO_PIN		GPIO_PIN_7
#endif

#endif


#endif