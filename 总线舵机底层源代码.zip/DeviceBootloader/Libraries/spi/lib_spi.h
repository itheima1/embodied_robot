#ifndef __LIB_SPI_H__
#define __LIB_SPI_H__

#include "SPI_config.h"


#if USE_LIB_SPI_0
#include "lib_spi0.h"
#endif

#if USE_LIB_SPI_1
#include "lib_spi1.h"
#endif


void lib_spi_init();
void lib_spi_deinit();



#endif