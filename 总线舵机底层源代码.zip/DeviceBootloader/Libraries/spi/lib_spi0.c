#include "lib_spi0.h"

#if USE_LIB_SPI_0


#define __SPIx_MOSI_ENABLE	SPI0_MOSI_ENABLE
#define __SPIx_MISO_ENABLE	SPI0_MISO_ENABLE
#define	__SPIx_CLK_RCU		SPI0_CLK_RCU
#define	__SPIx_CLK_PORT		SPI0_CLK_PORT
#define	__SPIx_CLK_PIN		SPI0_CLK_PIN
#define	__SPIx_CLK_AF		SPI0_CLK_AF
#define	__SPIx_MOSI_RCU		SPI0_MOSI_RCU
#define	__SPIx_MOSI_PORT	SPI0_MOSI_PORT
#define	__SPIx_MOSI_PIN		SPI0_MOSI_PIN
#define	__SPIx_MOSI_AF		SPI0_MOSI_AF
#define	__SPIx_MISO_RCU		SPI0_MISO_RCU
#define	__SPIx_MISO_PORT	SPI0_MISO_PORT
#define	__SPIx_MISO_PIN		SPI0_MISO_PIN
#define	__SPIx_MISO_AF		SPI0_MISO_AF

#define __SPIx_RCU		RCU_SPI0
#define __SPIx			SPI0

#define __SPI_PARAM_PSC			SPI0_PARAM_PSC
#define __SPI_PARAM_CPOL_CPHA	SPI0_PARAM_CPOL_CPHA
#define __SPI_PARAM_ENDIAN		SPI0_PARAM_ENDIAN


#define __SPI_FUNC_INIT			lib_spi0_init
#define __SPI_FUNC_DEINIT		lib_spi0_deinit
#define __SPI_FUNC_WRITE		lib_spi0_write
#define __SPI_FUNC_READ			lib_spi0_read
#define __SPI_FUNC_WRITE_READ	lib_spi0_write_read


void __SPI_FUNC_INIT() {
	///// GPIO 
	lib_io_af_pp(__SPIx_CLK_RCU, __SPIx_CLK_PORT, __SPIx_CLK_PIN, __SPIx_CLK_AF);
#if __SPIx_MOSI_ENABLE
	lib_io_af_pp(__SPIx_MOSI_RCU, __SPIx_MOSI_PORT, __SPIx_MOSI_PIN, __SPIx_MOSI_AF);
#endif
#if __SPIx_MISO_ENABLE	
	lib_io_af_pp(__SPIx_MISO_RCU, __SPIx_MISO_PORT, __SPIx_MISO_PIN, __SPIx_MISO_AF);
#endif
	///// SPI
    rcu_periph_clock_enable(__SPIx_RCU);

    spi_parameter_struct spi_init_struct;
    spi_init_struct.device_mode          = SPI_MASTER;
    spi_init_struct.trans_mode           = SPI_TRANSMODE_FULLDUPLEX;
    spi_init_struct.frame_size           = SPI_FRAMESIZE_8BIT;
    // negative slave select
    spi_init_struct.nss                  = SPI_NSS_SOFT;
    spi_init_struct.clock_polarity_phase = __SPI_PARAM_CPOL_CPHA;
    spi_init_struct.prescale             = __SPI_PARAM_PSC;
    spi_init_struct.endian               = __SPI_PARAM_ENDIAN;

    spi_init(__SPIx, &spi_init_struct);
	spi_enable(__SPIx);
}

void __SPI_FUNC_DEINIT() {
	spi_disable(__SPIx);
}

#if __SPIx_MOSI_ENABLE
void __SPI_FUNC_WRITE(uint8_t dat) {
	while(RESET == spi_i2s_flag_get(__SPIx, SPI_FLAG_TBE));
	spi_i2s_data_transmit(__SPIx, dat);
	while(RESET == spi_i2s_flag_get(__SPIx, SPI_FLAG_RBNE));
	spi_i2s_data_receive(__SPIx);
}
#endif

#if __SPIx_MISO_ENABLE
uint8_t __SPI_FUNC_READ() {
	while(RESET == spi_i2s_flag_get(__SPIx, SPI_FLAG_TBE));
	spi_i2s_data_transmit(__SPIx, 0x00);
	while(RESET == spi_i2s_flag_get(__SPIx, SPI_FLAG_RBNE));
	return spi_i2s_data_receive(__SPIx);
}
#endif

#if __SPIx_MOSI_ENABLE && __SPIx_MISO_ENABLE
uint8_t __SPI_FUNC_WRITE_READ(uint8_t dat) {
	while(RESET == spi_i2s_flag_get(__SPIx, SPI_FLAG_TBE));
	spi_i2s_data_transmit(__SPIx, dat);
	while(RESET == spi_i2s_flag_get(__SPIx, SPI_FLAG_RBNE));
	return spi_i2s_data_receive(__SPIx);
}
#endif



#endif