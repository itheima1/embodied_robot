#ifndef __SPI_CONFIG_H__
#define __SPI_CONFIG_H__

#include "../gpio/lib_gpio.h"


#define USE_LIB_SPI_0	1
#define USE_LIB_SPI_1	0


/** SPI PIN Table
/////////////////////////////////////////
//|-------|-----|-----------|-----------|
//| SPI 0 |	SCK	|	PA5		|	AF0		|
//| 	  |		|-----------|-----------|
//| 	  |		|	PB3		|	AF0		|
//| 	  |		|-----------|-----------|
//| 	  |		|	PB13	|	AF0		|
//|       |-----|-----------|-----------|
//| 	  | MOSI|	PA7		|	AF0		|
//| 	  |		|-----------|-----------|
//| 	  |		|	PB5		|	AF0		|
//| 	  |		|-----------|-----------|
//| 	  |		|	PB15	|	AF0		|
//|       |-----|-----------|-----------|
//| 	  | MISO|	PA6		|	AF0		|
//| 	  |		|-----------|-----------|
//| 	  |		|	PB4		|	AF0		|
//| 	  |		|-----------|-----------|
//| 	  |		|	PB14	|	AF0		|
//|       |-----|-----------|-----------|
//| 	  | NSS	|	PA4		|	AF0		|
//| 	  |		|-----------|-----------|
//| 	  |		|	PA15	|	AF0		|
//| 	  |		|-----------|-----------|
//| 	  |		|	PB12	|	AF0		|
//|-------|-----|-----------|-----------|
//|///////|//////////////////////////////
//|-------|-----|-----------|-----------|
//|	SPI 1 |	SCK |	PB1		|	AF6		|
//| 	  |		|-----------|-----------|
//|       |		|	PB10	|	AF7		|
//| 	  |		|-----------|-----------|
//|       |		|	PB13	|	AF0		|
//|       |-----|-----------|-----------|
//|       |	MOSI|	PA14	|	AF6		|
//| 	  |		|-----------|-----------|
//|       |		|	PB15	|	AF0		|
//|       |-----|-----------|-----------|
//|       |	MISO|	PA13	|	AF6		|
//|       |		|	PB14	|	AF0		|
//|       |-----|-----------|-----------|
//|       |	NSS |	PA4		|	AF6		|
//|       |		|	PA15	|	AF6		|
//|       |		|	PB9		|	AF7		|
//|       |		|	PB12	|	AF7		|
//|-------|-----|-----------|-----------|
/////////////////////////////////////////
**/
/**
//Ԥ��Ƶ
	SPI_PSC_x xΪ(2, 4, 8, 16, 32, 64, 128, 256)
	
//���Ժ���λ��
	SPI_CK_PL_LOW_PH_1EDGE��	0��0
	SPI_CK_PL_HIGH_PH_1EDGE��	1��0
	SPI_CK_PL_LOW_PH_2EDGE��	0��1
	SPI_CK_PL_HIGH_PH_2EDGE��	1��1

// ��С�ˣ�
	SPI_ENDIAN_MSB�� ���
	SPI_ENDIAN_LSB�� С��
**/

////////////////////////////// SPI 0/////////////////////////
#if USE_LIB_SPI_0
#define SPI0_SOFT			0
#define SPI0_MOSI_ENABLE	1
#define SPI0_MISO_ENABLE	1

////CLK
#define SPI0_CLK_RCU	RCU_GPIOA
#define SPI0_CLK_PORT	GPIOA
#define SPI0_CLK_PIN	GPIO_PIN_5
#define SPI0_CLK_AF		GPIO_AF_0

////MOSI
#if SPI0_MOSI_ENABLE
#define SPI0_MOSI_RCU	RCU_GPIOA
#define SPI0_MOSI_PORT	GPIOA
#define SPI0_MOSI_PIN	GPIO_PIN_7
#define SPI0_MOSI_AF	GPIO_AF_0
#endif

////MISO
#if SPI0_MISO_ENABLE
#define SPI0_MISO_RCU	RCU_GPIOA
#define SPI0_MISO_PORT	GPIOA
#define SPI0_MISO_PIN	GPIO_PIN_6
#define SPI0_MISO_AF	GPIO_AF_0
#endif

///////// PARAM
// PSC(2,4,8,16,32,64,128,256)
#define SPI0_PARAM_PSC			SPI_PSC_8
#define SPI0_PARAM_CPOL_CPHA	SPI_CK_PL_LOW_PH_1EDGE
#define SPI0_PARAM_ENDIAN		SPI_ENDIAN_MSB


#endif



//////////////////////////////////////////////////////////////////////////////////////





#endif