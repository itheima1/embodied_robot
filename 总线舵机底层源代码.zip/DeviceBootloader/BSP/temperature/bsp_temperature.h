#ifndef __BSP_TEMPERATURE_H__
#define __BSP_TEMPERATURE_H__


#include "board_config.h"

void Temperature_init();
void Temperature_loop();


extern void Temperature_on_value(uint8_t temperature);



#endif