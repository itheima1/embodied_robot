#include "bsp_temperature.h"
#include <math.h>

// ���� Steinhart-Hart ���̵ĳ���
#define A 663.2577213853299
#define B -45.5162884380417
#define C 0.06967111805378211


// ������ת��Ϊ���϶��¶�
static double R_to_T(double R) {
    if (R <= 0) {
        return -1;
    }

	double logR = log(R);
	
    // ���㿪�����¶�
    double T_kelvin = (A + B * logR + C * logR * logR * logR);
    
    // ת��Ϊ���϶�
    return T_kelvin - 273.15;
}



void Temperature_init() {
}

void Temperature_loop() {
	static uint8_t i = 0;
	static uint32_t sum = 0;
	static uint16_t min = 4095;
	static uint16_t max = 0;

	uint16_t val = TEMPERATURE_GET_VALUE();
	
	if(i == TEMPERATURE_SAMPLE_TIME) {
		sum -= min;
		sum -= max;
		uint16_t avg = sum / (TEMPERATURE_SAMPLE_TIME - 2);

		// �����ѹ
		float v = avg * 3.3 / 4096;

		// �������ֵ
		float r = (3.3 - v) * 10000 / v;
		
		uint8_t t = (uint8_t)round(R_to_T(r));
		
//		uint8_t t = (uint8_t)(1.45f - avg * 3.3f / 4096) * 1000 / 4.3f + 25;
		
		Temperature_on_value(t);
		
		sum = 0;
		min = 4095;
		max = 0;
		i = 0;
	} else {
		sum += val;
		if(min > val) min = val;
		if(max < val) max = val;
		i++;
	}
}

void Temperature_get() {
}