#include "bsp_AS5600.h"


void AS5600_init() {
	
}

uint16_t AS5600_get_position() {
	uint8_t data[2];
	uint8_t ret = AS5600_READ(AS5600_ADDR, 0x0C, data, 2);
	
	return (data[0] << 8) + data[1];
}