#ifndef __BSP_AS5600_H__
#define __BSP_AS5600_H__

#include "board_config.h"

void AS5600_init();

uint16_t AS5600_get_position();



#endif