#include "bsp_gd25qxx.h"
#include <string.h>  // ����memcmp��֤

// ȫ�ֱ�������
uint32_t gd25qxx_max_address = 0;    // ����ַ���ֽڣ�
static bool is_initialized = false;  // ��ʼ����־

/* Private Function Prototypes */
static void WriteEnable(void);
static void WaitBusy(void);
static bool ValidateAddress(uint32_t addr, uint32_t len);

/*********************** ��ʼ������������ ?************************/
void GD25Qxx_Init(void)
{
    // Ӳ����ʼ�����û���ʵ��CS���ź�SPI���ã�
    GD25Qxx_CS_INIT();
    GD25Qxx_CS(1);  // CS��ʼ�ߵ�ƽ

    // ��ȡ������Ϣ
    uint32_t capacity_kb = GD25Qxx_GetCapacityKB();
    if (capacity_kb == 0) {
        is_initialized = false;
        return;
    }

    gd25qxx_max_address = capacity_kb * 1024;
    is_initialized = true;
}

uint16_t GD25Qxx_ReadID(void)
{
    uint16_t id = 0;
    GD25Qxx_CS(0);
    GD25Qxx_RW(0x90);
    GD25Qxx_RW(0x00);
    GD25Qxx_RW(0x00);
    GD25Qxx_RW(0x00);

    id |= GD25Qxx_RW(0xFF) << 8;
    id |= GD25Qxx_RW(0xFF);
    GD25Qxx_CS(1);
    return id;
}

uint32_t GD25Qxx_GetCapacityKB(void)
{
    GD25Qxx_CS(0);
    GD25Qxx_RW(0x9F); // JEDEC IDָ��

    uint8_t manufacturer 	= GD25Qxx_RW(0xFF); // ������ID
    uint8_t deviceId_h 		= GD25Qxx_RW(0xFF); // Device ID H
    uint8_t capacity_code 	= GD25Qxx_RW(0xFF); // Device ID L
    GD25Qxx_CS(1);

    // �������루ʾ����GD25Q16C=16Mbit=2048KB��
    switch (capacity_code) {
    case 0x17:
        return 8192;  // 64Mbit (8MB)
    case 0x16:
        return 4096;  // 32Mbit
    case 0x15:
        return 2048;  // 16Mbit
    case 0x14:
        return 1024;  // 8Mbit
    case 0x13:
        return 512;	 // 4Mbit
    case 0x12:
        return 256;	 // 2Mbit
    default:
        return 0;     // δ֪����
    }

}

/*********************** ���Ĳ��� ?************************/
void GD25Qxx_EraseSector(uint32_t addr)
{
    if (!ValidateAddress(addr, GD25QXX_SECTOR_SIZE)) return;

    // ��ַ���뵽������ʼ
    addr = (addr / GD25QXX_SECTOR_SIZE) * GD25QXX_SECTOR_SIZE;

    WriteEnable();
    WaitBusy();

    GD25Qxx_CS(0);
    GD25Qxx_RW(0x20);                   // Sector Eraseָ��
    GD25Qxx_RW((addr >> 16) & 0xFF);     // ��ַ��8λ
    GD25Qxx_RW((addr >> 8)  & 0xFF);     // ��8λ
    GD25Qxx_RW(addr & 0xFF);             // ��8λ
    GD25Qxx_CS(1);

    WaitBusy();  // �ȴ��������
}

void GD25Qxx_Write(uint8_t *pData, uint32_t addr, uint32_t len)
{
    if (!ValidateAddress(addr, len) || !pData) return;

    while (len > 0) {
        // ���㵱ǰҳʣ��ռ�
        uint16_t page_offset = addr % GD25QXX_PAGE_SIZE;
        uint16_t write_len = GD25QXX_PAGE_SIZE - page_offset;
        if (write_len > len) write_len = len;

        WriteEnable();
        WaitBusy();

        GD25Qxx_CS(0);
        GD25Qxx_RW(0x02);                   // Page Programָ��
        GD25Qxx_RW((addr >> 16) & 0xFF);     // ��ַ��8λ
        GD25Qxx_RW((addr >> 8)  & 0xFF);     // ��8λ
        GD25Qxx_RW(addr & 0xFF);             // ��8λ

        for (uint16_t i = 0; i < write_len; i++) {
            GD25Qxx_RW(pData[i]);
        }
        GD25Qxx_CS(1);

        pData  += write_len;
        addr   += write_len;
        len    -= write_len;
    }
}

void GD25Qxx_Read(uint8_t *pData, uint32_t addr, uint32_t len)
{
    if (!ValidateAddress(addr, len) || !pData) return;

    GD25Qxx_CS(0);
    GD25Qxx_RW(0x03);                   // Readָ��
    GD25Qxx_RW((addr >> 16) & 0xFF);    // ��ַ��8λ
    GD25Qxx_RW((addr >> 8)  & 0xFF);    // ��8λ
    GD25Qxx_RW(addr & 0xFF);            // ��8λ

    for (uint32_t i = 0; i < len; i++) {
        pData[i] = GD25Qxx_RW(0xFF);    // ������ȡ
    }
    GD25Qxx_CS(1);
}

/*********************** �߼����� ?************************/
void GD25Qxx_FactoryReset(void)
{
    uint32_t sectors = gd25qxx_max_address / GD25QXX_SECTOR_SIZE;
    for (uint32_t i = 0; i < sectors; i++) {
        GD25Qxx_EraseSector(i * GD25QXX_SECTOR_SIZE);
    }
}

bool GD25Qxx_IsReady(void)
{
    return is_initialized;
}

/*********************** ˽�к��� ?************************/
static void WriteEnable(void)
{
    GD25Qxx_CS(0);
    GD25Qxx_RW(0x06); // WRENָ��
    GD25Qxx_CS(1);
}

static void WaitBusy(void)
{
    uint8_t status;
    do {
        GD25Qxx_CS(0);
        GD25Qxx_RW(0x05); // Read Status Register
        status = GD25Qxx_RW(0xFF);
        GD25Qxx_CS(1);
    } while (status & 0x01); // ���BUSYλ
}

static bool ValidateAddress(uint32_t addr, uint32_t len)
{
    if (!is_initialized) return false;
    if (addr >= gd25qxx_max_address) return false;
    if ((addr + len) > gd25qxx_max_address) return false;
    return true;
}
