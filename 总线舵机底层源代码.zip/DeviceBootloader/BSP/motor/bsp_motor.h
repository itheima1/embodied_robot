#ifndef __BSP_MOTOR_H__
#define __BSP_MOTOR_H__


#include "board_config.h"


void Motor_init();

#define Motor_power_on()	SW_ON()
#define Motor_power_off()	SW_OFF()


#endif