#ifndef __BSP_MOTOR_VOLTAGE_H__
#define __BSP_MOTOR_VOLTAGE_H__


#include "board_config.h"


void Voltage_init();


void Voltage_loop();


void Voltage_on_value(uint8_t voltage);

#endif