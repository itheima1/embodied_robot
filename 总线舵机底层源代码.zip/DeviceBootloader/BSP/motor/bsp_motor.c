#include "bsp_motor.h"



void Motor_init() {
	lib_io_pp(SW_RCU, SW_PIN);
}
