#ifndef __BSP_MOTOR_CURRENT_H__
#define __BSP_MOTOR_CURRENT_H__


#include "board_config.h"


void Current_init();

void Current_loop();


void Current_on_value(uint16_t current);

#endif