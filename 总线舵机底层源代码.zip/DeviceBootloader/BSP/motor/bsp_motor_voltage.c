#include "bsp_motor_voltage.h"



void Voltage_init() {
	
}


void Voltage_loop() {
	static uint8_t i = 0;
	static uint32_t sum = 0;
	static uint16_t min = 4095;
	static uint16_t max = 0;

	uint16_t val = VOLTAGE_GET_VALUE();
	
	if(i == VOLTAGE_SAMPLE_TIME) {
		sum -= min;
		sum -= max;
		uint16_t avg = sum / (VOLTAGE_SAMPLE_TIME - 2);

		// �����ѹ
		float v = avg * 3.3 / 4096 * 6.1;

		Voltage_on_value((uint8_t)(v * 10));
		
		sum = 0;
		min = 4095;
		max = 0;
		i = 0;
	} else {
		sum += val;
		if(min > val) min = val;
		if(max < val) max = val;
		i++;
	}

}