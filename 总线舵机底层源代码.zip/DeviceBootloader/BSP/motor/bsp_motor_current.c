#include "bsp_motor_current.h"



void Current_init() {
}


void Current_loop() {
	
	static uint8_t i = 0;
	static uint32_t sum = 0;
	static uint16_t min = 4095;
	static uint16_t max = 0;

	uint16_t val = CURRENT_GET_VALUE();
	
	if(i == CURRENT_SAMPLE_TIME) {
		sum -= min;
		sum -= max;
		uint16_t avg = sum / (CURRENT_SAMPLE_TIME - 2);

		// �����ѹ
		float v = avg * 3.3 / 4096;

		Current_on_value((uint16_t)(v * 200));
		
		sum = 0;
		min = 4095;
		max = 0;
		i = 0;
	} else {
		sum += val;
		if(min > val) min = val;
		if(max < val) max = val;
		i++;
	}
}