#ifndef __BOARD_CONFIG_H__
#define __BOARD_CONFIG_H__

#include <stdio.h>
#include "Log.h"
#include "lib_peripherals.h"



///////////////////////////// Device UUID ////////////////////
#define MCU_ID_1	(*(volatile uint32_t *)(uint32_t)(0x1FFFF7E0))
#define MCU_ID_2	(*(volatile uint32_t *)(uint32_t)(0x1FFFF7AC))
#define MCU_ID_3	(*(volatile uint32_t *)(uint32_t)(0x1FFFF7B4))		


//////////////////////////// LED //////////////////////////////////////////
#define LED_INIT()			lib_io_pp(RCU_GPIOB, GPIOB, GPIO_PIN_6)
#define LED_on()			lib_io_write(GPIOB, GPIO_PIN_6, 1)
#define LED_off()			lib_io_write(GPIOB, GPIO_PIN_6, 0)


//////////////////////////// GD25Qxx Flash ///////////////////////////
#define GD25Qxx_CS_RCU		RCU_GPIOA
#define GD25Qxx_CS_PIN		GPIOA, GPIO_PIN_4

#define GD25Qxx_CS_INIT()	lib_io_pp_pu(GD25Qxx_CS_RCU, GD25Qxx_CS_PIN)
#define GD25Qxx_CS(val)		lib_io_write(GD25Qxx_CS_PIN, val)

#define GD25Qxx_RW(dat)		lib_spi0_write_read(dat)





#endif