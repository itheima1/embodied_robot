./objects/circular_queue.o: ..\Libraries\common\circular_queue.c \
  ..\Libraries\common\circular_queue.h ..\User\Log.h \
  C:\keil5\ARM\ARMCLANG\include\stdio.h \
  C:\keil5\ARM\ARMCLANG\include\string.h \
  C:\keil5\ARM\ARMCLANG\include\stdint.h \
  C:\keil5\ARM\ARMCLANG\include\stdbool.h \
  C:\keil5\ARM\ARMCLANG\include\stdlib.h
