./objects/lib_spi.o: ..\Libraries\spi\lib_spi.c \
  ..\Libraries\spi\lib_spi.h ..\Libraries\spi\SPI_config.h \
  ..\Libraries\spi\..\gpio\lib_gpio.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Include\gd32f3x0.h \
  C:\keil5\ARM\CMSIS\5.9.0\CMSIS\Core\Include\core_cm4.h \
  C:\keil5\ARM\ARMCLANG\include\stdint.h \
  C:\keil5\ARM\CMSIS\5.9.0\CMSIS\Core\Include\cmsis_version.h \
  C:\keil5\ARM\CMSIS\5.9.0\CMSIS\Core\Include\cmsis_compiler.h \
  C:\keil5\ARM\CMSIS\5.9.0\CMSIS\Core\Include\cmsis_armclang.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Include\system_gd32f3x0.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Include\gd32f3x0_libopt.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_adc.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_crc.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_ctc.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_dbg.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_dma.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_exti.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_fmc.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_gpio.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_syscfg.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_i2c.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_fwdgt.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_pmu.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_rcu.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_rtc.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_spi.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_timer.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_usart.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_wwdgt.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_misc.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_tsi.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_cec.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_cmp.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_dac.h \
  ..\Libraries\spi\lib_spi0.h
