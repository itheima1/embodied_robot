./objects/log.o: ..\User\Log.h C:\keil5\ARM\ARMCLANG\include\stdio.h \
  C:\keil5\ARM\ARMCLANG\include\string.h
