#include "Bootloader.h"
#include "Log.h"
#include "Task.h"

#define RAM_START_ADDRESS	((uint32_t)0x20000000)
#define RAM_SIZE			((uint32_t)0x00002000)				// 8KB


#define	IS_NULL_APP()		(g_boot.current_app_address == 0xFFFFFFFF)
#define	IS_VALID_APP()		(*((__IO uint32_t *)APP_ADDRESS) >= RAM_START_ADDRESS && *((__IO uint32_t *)APP_ADDRESS) < (RAM_START_ADDRESS + RAM_SIZE))

typedef void (*pFunction)(void);


extern Boot_t g_boot;
extern uint32_t	g_mac;

uint8_t g_led_state = 1;

static void BootToApp(void) {
    // ���ش����0x0800_4000��App�̼���ȡ��ջ����ַ��0x20001418��
    uint32_t stackTopAddr = *((__IO uint32_t *)APP_ADDRESS);

    LOG_INFO("stackTopAddr: 0x%08X\n", stackTopAddr);
    LOG_INFO("resetAddr: 0x%08X\n", *((__IO uint32_t *)(APP_ADDRESS + 4)));
    lib_peripherals_loop();
    delay_1ms(20);
    // ջ����ַ����ȷ�ķ�Χ [0x2000_0000, 0x20020000)
    if(stackTopAddr >= RAM_START_ADDRESS && stackTopAddr < (RAM_START_ADDRESS + RAM_SIZE)) {
        NVIC_DisableIRQ(SysTick_IRQn);
        lib_peripherals_deinit();
        Protocol_deinit();

        // 1. �������е��ⲿ�ж�
        __disable_irq();

        // 2. ����ջ����ַ
        __set_MSP(stackTopAddr); // 0xFFFFFFFF

        // 3. ���ش����0x0800_4004��Reset_Handler����ת���û���App ��ִ��Reset_Handler��
        uint32_t resetHandlerAddr = *((__IO uint32_t *)(APP_ADDRESS + 4));

        //printf("resetHandlerAddr: 0x%08X\n", resetHandlerAddr);
        //lib_peripherals_loop();

        pFunction Jump_To_Application = (pFunction) resetHandlerAddr;	// uint32_t *p = (uint32_t *)0x0800019d

        __ASM volatile ("DSB");
        __ASM volatile ("ISB");

        // ִ�к���
        Jump_To_Application();
    } else {
        printf("Load App Failed\n");
        lib_peripherals_loop();

        g_boot.upgrade_flag = UPGRADE_FLAG_OFF;
        g_boot.current_app_address = 0xFFFFFFFF;
        g_boot.download_state = DOWNLOAD_STATE_NONE;
        DM_write_boot(&g_boot);
    }
//
//	// ����MCU
//	NVIC_SystemReset();
}

void Bootloader_init() {
    // ��������
    DM_init();
    // Э���ʼ��
    Protocol_init();
	
	LED_INIT();

    LOG_INFO("MAC: 0x%08X", g_mac);


    if(g_boot.upgrade_flag == UPGRADE_FLAG_ON) {
        // ��Ҫ����
        if(g_boot.download_state == DOWNLOAD_STATE_NONE) {
            // δ��ʼ����û�а�װ�κ�App���ȴ��ϴ�
            Protocol_send_boot_ok();
        } else if(g_boot.download_state == DOWNLOAD_STATE_DOWNLOADING) {
            // �����У��������������У����������ϴ�����ʧ�ܣ����½���ʱ��״̬
            g_boot.download_state = DOWNLOAD_STATE_NONE;
            DM_write_boot(&g_boot);
        } else if(g_boot.download_state == DOWNLOAD_STATE_DOWNLOADED) {
            // �������, ������
        }
    } else {
		if(IS_VALID_APP()) {
			// �������֤��APP
			BootToApp();
		} else {
			// �����ⳬʱ���ȴ���װ����
			// �ȴ�����
			Task_suspend(Task_get_task_id(Bootloader_check_timeout_task));
		}
	}
}


void lib_usart0_on_recv(uint8_t *data, uint16_t len) {
    Protocol_recv_more(data, len);
}


void copy_flash_to_fmc(uint32_t flash_addr, uint32_t fmc_addr, uint32_t len) {

    lib_fmc_erase(fmc_addr, len);

#define BUFFER_SIZE	128
    uint8_t buffer[BUFFER_SIZE]; // ������

    while(len > 0) {
        uint32_t bytes_read = BUFFER_SIZE;
        if(len < BUFFER_SIZE) {
            bytes_read = len;
        }

        GD25Qxx_Read(buffer, flash_addr, bytes_read);
        lib_fmc_write(fmc_addr, buffer, bytes_read);

        flash_addr += bytes_read;
        fmc_addr += bytes_read;
        len -= bytes_read;
    }
}

void Bootloader_check_timeout_task() {
    static uint16_t timeout_cnt = 0;

    if(g_boot.upgrade_flag == UPGRADE_FLAG_OFF) return;

    if(g_boot.download_state == DOWNLOAD_STATE_NONE) {
        timeout_cnt++;
    } else {
        timeout_cnt = 0;
    }

    if(timeout_cnt > 10) {
		LOG_DEBUG("timeout to app");
		g_boot.upgrade_flag = UPGRADE_FLAG_OFF;
		DM_write_boot(&g_boot);
        BootToApp();
    }
}



void Bootloader_upgrade_task() {
    static uint16_t err_cnt = 0;
    static uint8_t  reload = 0;
    static uint32_t read_size = 0;
    static uint32_t offset = 0;

//	if(err_cnt > 100) {
//		g_boot.download_state = DOWNLOAD_STATE_NONE;
//		DM_write_boot(&g_boot);
//		err_cnt = 0;
//		return;
//	}

//    if(read_size > 0) {
//        uint8_t temp[16];
//        uint32_t read_len = 16;
//        if(read_size < read_len) {
//            read_len = read_size;
//        }
//        GD25Qxx_Read(temp, offset, read_len);

//        printf("%08X: ", offset);
//        for(uint16_t i = 0; i < read_len; i++) {
//            printf("%02X ", temp[i]);
//        }
//        printf("\r\n");

//        offset += read_len;
//        read_size -= read_len;

//        if(read_size == 0) {
//            printf("read finish\r\n");
//        }
//    }

    if(reload) {
        NVIC_SystemReset();
    }

    if(g_boot.download_state == DOWNLOAD_STATE_DOWNLOADED) {
        // ������ɣ�У��Flash CRC��ɣ�������fmc
        //////1. У��crc
        uint8_t next_index = DM_get_next_upgrade_index(&g_boot);
        uint32_t address = DM_get_next_upgrade_address(&g_boot);

        Upgrade_t upgrade;
        uint8_t status = DM_read_upgrade_info(&upgrade, next_index);
        if(UPGRADE_STATUS_SUCCESS != status) {
            // ��ȡʧ��
            Protocol_send_upgrade_error(CMD_FLASH_CRC, ERR_FLASH_CRC1);
            err_cnt++;
            return;
        }
        uint32_t crc32 = DM_crc_flash(address, upgrade.bin_size);

        if(crc32 != upgrade.bin_crc) {
            // У��ʧ��, ���ش������⣬����������
            g_boot.upgrade_flag = UPGRADE_FLAG_OFF;
            g_boot.download_state = DOWNLOAD_STATE_NONE;
            if(BOOT_STATUS_SUCCESS != DM_write_boot(&g_boot)) {
                Protocol_send_upgrade_error(CMD_FLASH_CRC, ERR_FLASH_CRC2);
                err_cnt++;
                return;
            }

            read_size = upgrade.bin_size;
            offset = address;

            Protocol_send_upgrade_error(CMD_FLASH_CRC, ERR_FLASH_CRC3);
            err_cnt++;
            return;
        }

        // CRC У��ɹ�
        Protocol_send_upgrade_error(CMD_FLASH_CRC, SUCCESS);

        /////2. ������FMC�����CRC
        uint32_t fmc_addr = APP_ADDRESS;
        copy_flash_to_fmc(address, fmc_addr, upgrade.bin_size);

        // У��fmc
        crc32 = DM_crc_fmc(fmc_addr, upgrade.bin_size);

        if(crc32 != upgrade.bin_crc) {
            // У��ʧ��, copy�������⣬��Ҫ���½��п���
            g_boot.download_state = DOWNLOAD_STATE_DOWNLOADED;
            Protocol_send_upgrade_error(CMD_FMC_CRC, ERR_FMC_CRC1);
            err_cnt++;
        } else {
            // У��ɹ�
            g_boot.download_state = DOWNLOAD_STATE_WAIT_RELOAD;
            g_boot.upgrade_flag = UPGRADE_FLAG_OFF;
            g_boot.current_app_address = address;
            g_boot.current_app_index = next_index;

            if(BOOT_STATUS_SUCCESS != DM_write_boot(&g_boot)) {
                // д��ʧ��
                Protocol_send_upgrade_error(CMD_FMC_CRC, ERR_FMC_CRC2);
                err_cnt++;
                return;
            }

            // У��ɹ�
            Protocol_send_upgrade_error(CMD_FMC_CRC, SUCCESS);
            reload = 1;
        }
    }
}

void Bootloader_led_task() {
	
}


