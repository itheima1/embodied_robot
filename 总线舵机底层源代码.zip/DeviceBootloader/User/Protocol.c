#include "Protocol.h"


#define MAX_DATA_LEN		64



#define MAX_WRITE_PARAM_LEN	24
#define MAX_READ_PARAM_LEN	24


#define FRAME_HEAD 	0xAA
#define FRAME_TAIL 	0xBB

#define RX_CMD_OTA_TAG		0x10
#define RX_CMD_OTA_INFO		0x11
#define RX_CMD_OTA_DATA		0x12
#define RX_CMD_OTA_FINISH	0x13


#define SUCCESS						0x00
#define ERR_WRITE_PARAM_OUT_LEN		0x10
#define ERR_READ_PARAM_FORMAT		0x11
#define ERR_READ_PARAM_OUT_LEN		0x12
#define ERR_OTA_TAG					0x13
#define ERR_OTA_INFO				0x14
#define ERR_OTA_DATA				0x15
#define ERR_OTA_FINISH				0x16



#define QUEUE_LEN	512

static CQ_Queue rx_queue;

extern Boot_t 		g_boot;
extern uint32_t		g_mac;

extern uint8_t 		g_led_state;

union intToBytes {
    uint32_t i;
    unsigned char bytes[4];
};

union shortToBytes {
    uint16_t s;
    unsigned char bytes[2];
};


static void int_to_bytes(uint32_t value, uint8_t* bytes) {
    union intToBytes converter;
    converter.i = value;

    bytes[0] = converter.bytes[0];
    bytes[1] = converter.bytes[1];
    bytes[2] = converter.bytes[2];
    bytes[3] = converter.bytes[3];
}

static uint32_t bytes_to_int(uint8_t* bytes) {
    union intToBytes converter;

    converter.bytes[0] = bytes[0];
    converter.bytes[1] = bytes[1];
    converter.bytes[2] = bytes[2];
    converter.bytes[3] = bytes[3];

    return converter.i;
}

static void short_to_bytes(uint16_t value, uint8_t* bytes) {
    union shortToBytes converter;
    converter.s = value;

    bytes[0] = converter.bytes[0];
    bytes[1] = converter.bytes[1];
}

static uint16_t bytes_to_short(uint8_t* bytes) {
    union shortToBytes converter;

    converter.bytes[0] = bytes[0];
    converter.bytes[1] = bytes[1];

    return converter.s;
}


void Protocol_init() {
    CQ_Init(&rx_queue, QUEUE_LEN);
}

void Protocol_deinit() {
	CQ_Free(&rx_queue);
}


uint8_t check_sum(uint8_t *buff, uint8_t len) {
    uint16_t sum = 0;
    for(uint8_t i = 2; i < len - 2; i++) {
        sum += buff[i];
    }
    return (uint8_t)(sum & 0xFF);
}


void Protocol_recv_one(uint8_t value) {
    CQ_Enqueue(&rx_queue, value);
}

void Protocol_recv_more(uint8_t *data, uint16_t len) {
    CQ_EnqueueList(&rx_queue, data, len);
}


static void response_ota_error(uint32_t mac, uint8_t cmd, uint8_t error_code) {
    uint8_t buff[12];
    buff[0] = FRAME_HEAD;
    buff[1] = FRAME_HEAD;
    buff[2] = 0xFD;
    buff[3] = cmd;
    buff[4] = 5;
	int_to_bytes(mac, &buff[5]);
    buff[9] = error_code;
    buff[10] = check_sum(buff, 12);
    buff[11] = FRAME_TAIL;
    lib_usart0_send_data(buff, 12);
}

static void response_scan_mac(uint8_t cmd, uint32_t mac, uint8_t id) {
	uint8_t buff[12];
	buff[0] = FRAME_HEAD;
    buff[1] = FRAME_HEAD;
	buff[2] = 0xFE;
    buff[3] = cmd;
	buff[4] = 5;
	int_to_bytes(mac, &buff[5]);
	buff[9] = id;
	buff[10] = check_sum(buff, 12);
	buff[11] = FRAME_TAIL;
	lib_usart0_send_data(buff, 12);
}

void Protocol_send_boot_ok() {
	response_ota_error(g_mac, RX_CMD_OTA_TAG, SUCCESS);
}

void Protocol_send_upgrade_error(uint8_t cmd, uint8_t error_code) {
	response_ota_error(g_mac, cmd, error_code);
}

static void do_work(uint8_t *buff, uint8_t len) {
    // ����Э��ɻ�
    uint8_t id = buff[2];
    uint8_t cmd = buff[3];

    if(id == 0x7D) {
		uint32_t mac = bytes_to_int(&buff[5]);
		if(mac != g_mac) {	
			return;
		}
		if(cmd == RX_CMD_OTA_TAG) {
			// ota ��Ǹ���
			g_boot.upgrade_flag = UPGRADE_FLAG_ON;
			if(BOOT_STATUS_SUCCESS != DM_write_boot(&g_boot)) {
				// д���¼ʧ��
				response_ota_error(g_mac, cmd, ERR_OTA_TAG);
				return;
			}
			response_ota_error(g_mac, cmd, SUCCESS);
		} else if(cmd == RX_CMD_OTA_INFO) {
			uint32_t crc = bytes_to_int(&buff[9]);
			uint32_t bin_size = bytes_to_int(&buff[13]);
			uint8_t mojor = buff[17];
			uint8_t minor = buff[18];
			
			/// 1. д�� �������ݼ�¼
			uint8_t next_index = DM_get_next_upgrade_index(&g_boot);
			
			Upgrade_t upgrade;
			upgrade.bin_crc = crc;
			upgrade.bin_size = bin_size;
			upgrade.version_mojor = mojor;
			upgrade.version_minor = minor;
			
			if(UPGRADE_STATUS_SUCCESS != DM_write_upgrade_info(&upgrade, next_index)) {
				// д���¼ʧ��
				response_ota_error(g_mac, cmd, ERR_OTA_INFO);
				return;
			}
			/// 2. д����¹��̼�¼
			g_boot.upgrade_flag = UPGRADE_FLAG_ON;
			g_boot.download_state = DOWNLOAD_STATE_DOWNLOADING;
			if(BOOT_STATUS_SUCCESS != DM_write_boot(&g_boot)) {
				// д���¼ʧ��
				response_ota_error(g_mac, cmd, ERR_OTA_INFO);
				return;
			}
			response_ota_error(g_mac, cmd, SUCCESS);
		} else if(cmd == RX_CMD_OTA_DATA) {
			uint32_t offset = bytes_to_int(&buff[9]);
			uint8_t pack_len = buff[13];
			
			uint8_t next_index = DM_get_next_upgrade_index(&g_boot);
			
			uint8_t *tmp = malloc(sizeof(uint8_t) * pack_len);
			memcpy(tmp, &buff[14], pack_len);
			
			if(UPGRADE_STATUS_SUCCESS != DM_write_upgrade_bin(next_index, offset, tmp, pack_len)) {
				free(tmp);
				response_ota_error(g_mac, cmd, ERR_OTA_DATA);
				return;
			}
			free(tmp);
			
			response_ota_error(g_mac, cmd, SUCCESS);
		} else if(cmd == RX_CMD_OTA_FINISH) {
			/// д����¹��̼�¼
			g_boot.download_state = DOWNLOAD_STATE_DOWNLOADED;
			if(BOOT_STATUS_SUCCESS != DM_write_boot(&g_boot)) {
				// д���¼ʧ��
				response_ota_error(g_mac, cmd, ERR_OTA_FINISH);
				return;
			}
			response_ota_error(g_mac, cmd, SUCCESS);
		}
	}else if(id == 0x7E) {
		if(cmd == 0x00) {
			// ɨ����Ϣ
			uint8_t type = buff[5];
			uint8_t h_mac = buff[6];
			uint8_t m_mac = buff[7];
			uint8_t l_mac = buff[8];
			
			if(type == 0x00) {
				// �鿴��8λ
				if(((g_mac >> 16) & 0xFF) == h_mac) {
					// ��Ӧ ��ǰ��mac
					response_scan_mac(cmd, g_mac, 0xFF);
				}
			} else if(type == 0x01) {
				// �鿴��8λ����8λ
				if(((g_mac >> 16) & 0xFF) == h_mac && ((g_mac >> 8) & 0xFF) == m_mac) {
					response_scan_mac(cmd, g_mac, 0xFF);
				}
			} else if(type == 0x02) {
				// �鿴��8λ����8λ����8λ
				if(((g_mac >> 16) & 0xFF) == h_mac && ((g_mac >> 8) & 0xFF) == m_mac && ((g_mac >> 0) & 0xFF) == l_mac) {
					response_scan_mac(cmd, g_mac, 0xFF);
				}
			}	
		} else if(cmd == 0x02) {
			// ��˸
			uint32_t mac = bytes_to_int(&buff[5]);
			if(mac != g_mac) {
				return;
			}
			
			uint8_t state = buff[9];
			g_led_state = state;
		}
	}

}


void Protocol_parse() {
    //�������߼�
    //�ӻ��ζ�����ȡ���ݳ������н���
    // ֡ͷ  ID  ����λ	 ���ݳ���	����λ	У��λ	֡β

    // ֡ͷ ID ����λ ���ݳ���(len)

    /// ���ݳ��ȱ�Ȼ���ڵ���5
    if(CQ_Size(&rx_queue) < 5) return;

    // ֡ͷ
    uint8_t head1;
    CQ_GetElement(&rx_queue, 0, &head1);
    uint8_t head2;
    CQ_GetElement(&rx_queue, 1, &head2);
    if(head1 != FRAME_HEAD || head2 != FRAME_HEAD) {
        CQ_Dequeue(&rx_queue, 0);
        return;// ������ִ��
    }

    // ID
    uint8_t id;
    CQ_GetElement(&rx_queue, 2, &id);

    // ����λ
    uint8_t cmd;
    CQ_GetElement(&rx_queue, 3, &cmd);
//	if(cmd > MAX_CMD_NUM) {
//		CQ_Dequeue(&rx_queue, 0);
//		return;
//	}

    // ���ݳ���
    uint8_t len;
    CQ_GetElement(&rx_queue, 4, &len);
    ////// �費��ҪУ�飬��������Ч��
    /// �����ĵ�����Ҫȥ�ҵ�Э�����������Э�飬
    if(len > MAX_DATA_LEN) {
        CQ_Dequeue(&rx_queue, 0);
        return;
    }

    /// ȷ���ܹ��չ�һ��Э��
    if(len + 7 > CQ_Size(&rx_queue)) {
        // ���ݲ���һ��Э��
        return;
    }

    // ȷ���ܹ���һ��Э��
    // ֡β (У��)
    uint8_t tail;
    CQ_GetElement(&rx_queue, len + 6, &tail);
    if(tail != FRAME_TAIL) {
        //����һ��Э�飬������
        CQ_Dequeue(&rx_queue, 0);
        return;
    }

    // У��λ(У��)
    // �����У��ͣ��Ͷ�����У��λ���бȽϣ���ͬ����һ��Э�飬��ͬ���Ǽٵ�
    uint8_t check;
    CQ_GetElement(&rx_queue, len + 5, &check);
    // ����λ + ���ݳ���λ + ����λ)�Ľ����ȡ��8λ
    uint16_t sum = 0;
    sum += id;
    sum += cmd;
    sum += len;
    // ����λ
    uint8_t data;
    for(uint8_t i = 0; i < len; i++) {
        CQ_GetElement(&rx_queue, 5 + i, &data);
        sum += data;
    }
    sum &= 0xFF;

    if(check != sum) {
        //����һ��Э�飬������
        CQ_Dequeue(&rx_queue, 0);
        return;
    }
	
    ///////////////////// ��Ļ����һ��Э��
    // ����λ
    uint8_t buff[len + 7];

    uint8_t v;
    for(uint8_t i = 0; i < len + 6; i++) {
        CQ_Dequeue(&rx_queue, &v);
        buff[i] = v;
    }
    do_work(buff, len + 7);
}