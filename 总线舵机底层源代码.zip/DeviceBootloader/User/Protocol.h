#ifndef __PROTOCOL_H__
#define __PROTOCOL_H__


#include "gd32f3x0.h"
#include "stdlib.h"
#include "lib_peripherals.h"
#include "DataManage.h"


#define CMD_FLASH_CRC			0x20
#define CMD_FMC_CRC				0x21

#define ERR_FLASH_CRC1			0x01
#define ERR_FLASH_CRC2			0x02
#define ERR_FLASH_CRC3			0x03
#define ERR_FLASH_CRC4			0x04

#define ERR_FMC_CRC1			0x01
#define ERR_FMC_CRC2			0x02
#define ERR_FMC_CRC3			0x03
#define ERR_FMC_CRC4			0x04



#define UPGRADE_TYPE_REQUEST	0x00
#define UPGRADE_TYPE_INFO		0x01
#define UPGRADE_TYPE_DATA		0x02
#define UPGRADE_TYPE_FINISH		0x03

#define CHECK_TYPE_FLASH_CRC	0x00
#define CHECK_TYPE_FMC_CRC		0x01

#define RESPONSE_SUCCESS				0x00
#define RESPONSE_ERROR_UPGREADE_WRITE	0x01
#define RESPONSE_ERROR_UPGREADE_ERASE	0x02
#define RESPONSE_ERROR_BOOT_WRITE		0x03
#define RESPONSE_ERROR_UPGREADE_READ	0x04
#define RESPONSE_ERROR_BOOT_READ		0x05
#define RESPONSE_ERROR_CRC_FAILED		0x06


///////////////////////////// Э��Ļ�������////////////////
void Protocol_init();
void Protocol_deinit();

//��������
void Protocol_recv_one(uint8_t value);
void Protocol_recv_more(uint8_t *value, uint16_t len);

void Protocol_parse();

/////////////////////////////////////////////////////////////////////////


//void Protocol_response(uint8_t cmd, uint8_t type, uint8_t result);
// ����������ɣ������ϴ�����
void Protocol_send_boot_ok();

void Protocol_send_upgrade_error(uint8_t cmd, uint8_t error_code);


#endif