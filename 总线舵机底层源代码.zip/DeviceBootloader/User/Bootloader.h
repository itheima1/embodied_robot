#ifndef __BOOTLOADER_H__
#define __BOOTLOADER_H__

#include "gd32f3x0.h"
#include "DataManage.h"
#include "Protocol.h"

#define Bootloader_parse_task	Protocol_parse


void Bootloader_init();
void Bootloader_upgrade_task();
void Bootloader_check_timeout_task();
void Bootloader_led_task();




#endif