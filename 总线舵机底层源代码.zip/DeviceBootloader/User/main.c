#include "systick.h"
#include <stdio.h>
#include "main.h"

#include "lib_peripherals.h"
#include "Task.h"
#include "Bootloader.h"
#include "Log.h"



void lib_timer5_on_interrupt() {
	Task_switch_handler();
}

int main(void)
{
	nvic_priority_group_set(NVIC_PRIGROUP_PRE4_SUB0);
    systick_config();

	// �����ʼ��
	lib_peripherals_init();
	
	LOG_INFO("Bootloader Start\r\n");

	Bootloader_init();

    while(1) {
		lib_peripherals_loop();
		Task_exec_handler();		
    }
}