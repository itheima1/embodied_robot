#include "DataManage.h"

#define CRC_SIZE	64

Boot_t 		g_boot;
uint32_t	g_mac;

void DM_init() {
	// chipid	
	uint32_t id1 = MCU_ID_1;
	uint32_t id2 = MCU_ID_2;
	uint32_t id3 = MCU_ID_3;
	
	printf("id1: %08X\r\n", id1);
	printf("id2: %08X\r\n", id2);
	printf("id3: %08X\r\n", id3);
	
	uint8_t data[12];
	memcpy(&data[0], &id1, 4);
	memcpy(&data[4], &id2, 4);
	memcpy(&data[8], &id3, 4);
	g_mac = DM_crc(data, 12);
	
    // ��ʼ���־û��洢
    GD25Qxx_Init();
	
    // ����Boot����
    if(BOOT_STATUS_SUCCESS != DM_read_boot(&g_boot)) {
		// ��һ�μ���δ��ʼ��
		g_boot.current_app_address = 0xFFFFFFFF;
		g_boot.current_app_index = 0xFF;
		g_boot.download_state = DOWNLOAD_STATE_NONE;
		g_boot.upgrade_flag = UPGRADE_FLAG_ON;
		DM_write_boot(&g_boot);
	}
}

uint32_t DM_crc(uint8_t* buffer, uint32_t len) {

    // 1. ��ʼ�� CRC ��Ԫ
    rcu_periph_clock_enable(RCU_CRC);            // ���� CRC ��Ԫʱ��
    crc_deinit();                               // ȷ�� CRC ��Ԫ���ڳ�ʼ״̬
    crc_data_register_reset();                  // ���� CRC ���ݼĴ���

    // 2. ���� CRC ��ʼֵ����׼ CRC-32 ��ʼֵ��
    uint32_t initial_value = 0;        // CRC-32 ��ʼֵ
    crc_init_data_register_write(initial_value);
    uint8_t data_format = INPUT_FORMAT_BYTE;

    crc_block_data_calculate(buffer, len, data_format);

    // 4. ��ȡ���յ� CRC ���
    uint32_t final_crc_result = crc_data_register_read();
    final_crc_result ^= 0xFFFFFFFF;
    return final_crc_result;
}

uint32_t DM_crc_flash(uint32_t address, uint32_t len) {
    // 1. ��ʼ�� CRC ��Ԫ
    rcu_periph_clock_enable(RCU_CRC);            // ���� CRC ��Ԫʱ��
    crc_deinit();                               // ȷ�� CRC ��Ԫ���ڳ�ʼ״̬
    crc_data_register_reset();                  // ���� CRC ���ݼĴ���

    // 2. ���� CRC ��ʼֵ����׼ CRC-32 ��ʼֵ��
    uint32_t initial_value = 0;        // CRC-32 ��ʼֵ
    crc_init_data_register_write(initial_value);

    // 3. �߶��߼��� CRC
    uint8_t buffer[CRC_SIZE]; // ������
    uint8_t data_format = INPUT_FORMAT_BYTE; // ���ݸ�ʽ������ 0 ��ʾ���ֽڴ���

    while(len > 0) {
        uint32_t bytes_read = CRC_SIZE;
        if(len < CRC_SIZE) {
            bytes_read = len;
        }
        GD25Qxx_Read(buffer, address, bytes_read);
        crc_block_data_calculate(buffer, bytes_read, data_format);
        address += bytes_read;
        len -= bytes_read;
    }

    // 4. ��ȡ���յ� CRC ���
    uint32_t final_crc_result = crc_data_register_read();
    final_crc_result ^= 0xFFFFFFFF;
    return final_crc_result;
}

uint32_t DM_crc_fmc(uint32_t address, uint32_t len) {
    // 1. ��ʼ�� CRC ��Ԫ
    rcu_periph_clock_enable(RCU_CRC);            // ���� CRC ��Ԫʱ��
    crc_deinit();                               // ȷ�� CRC ��Ԫ���ڳ�ʼ״̬
    crc_data_register_reset();                  // ���� CRC ���ݼĴ���

    // 2. ���� CRC ��ʼֵ����׼ CRC-32 ��ʼֵ��
    uint32_t initial_value = 0;        // CRC-32 ��ʼֵ
    crc_init_data_register_write(initial_value);

    // 3. �߶��߼��� CRC
    uint8_t buffer[CRC_SIZE]; // ������
    uint8_t data_format = INPUT_FORMAT_BYTE; // ���ݸ�ʽ������ 0 ��ʾ���ֽڴ���

    while(len > 0) {
        uint32_t bytes_read = CRC_SIZE;
        if(len < CRC_SIZE) {
            bytes_read = len;
        }
        lib_fmc_read(address, buffer, bytes_read);
        crc_block_data_calculate(buffer, bytes_read, data_format);
        address += bytes_read;
        len -= bytes_read;
    }

    // 4. ��ȡ���յ� CRC ���
    uint32_t final_crc_result = crc_data_register_read();
    final_crc_result ^= 0xFFFFFFFF;
    return final_crc_result;
}

BootStatus DM_read_boot(Boot_t *boot) {
//	GD25Qxx_read((uint8_t *)boot, BOOT_ADDRESS, sizeof(Boot_t));
    lib_fmc_read(BOOT_ADDRESS, (uint8_t *)boot, sizeof(Boot_t));

    // ����У��ʧ��
    if(boot->crc != DM_crc((uint8_t *)boot + 4, sizeof(Boot_t) - 4)) {
        return BOOT_STATUS_INFO_CRC;
    }

    return BOOT_STATUS_SUCCESS;
}

BootStatus DM_write_boot(Boot_t *boot) {
//	GD25Qxx_erase_sector(BOOT_ADDRESS / 4096);
//	GD25Qxx_write((uint8_t *)boot, BOOT_ADDRESS, sizeof(Boot_t));

    if(lib_fmc_erase(BOOT_ADDRESS, sizeof(Boot_t))) {
        return BOOT_STATUS_ERASE_ERR;
    }

    boot->crc = DM_crc((uint8_t *)boot + 4, sizeof(Boot_t) - 4);
    if(lib_fmc_write(BOOT_ADDRESS, (uint8_t*)boot, sizeof(Boot_t))) {
        return BOOT_STATUS_WRITE_ERR;
    }

    return BOOT_STATUS_SUCCESS;
}

uint8_t DM_get_next_upgrade_index(Boot_t *boot) {
    if(boot->crc != DM_crc((uint8_t *)boot + 4, sizeof(Boot_t) - 4)) {
        // У��ʧ�ܣ�˵�����ܴ�����û�а�װ���κ�app
        return 0;
    }
    return (boot->current_app_index + 1) % 3;
}

uint32_t DM_get_next_upgrade_address(Boot_t *boot) {
    uint8_t index = DM_get_next_upgrade_index(boot);
    uint32_t address;
    if(index == 0) {
        address = UPGRADE_BIN_1_ADDRESS;
    } else if(index == 1) {
        address = UPGRADE_BIN_2_ADDRESS;
    } else if(index == 2) {
        address = UPGRADE_BIN_3_ADDRESS;
    }
    return address;
}


UpgradeStatus DM_read_upgrade_info(Upgrade_t *upgrade, uint8_t index) {

    if(index > 2) {
        return UPGRADE_STATUS_OUT_INDEX;
    }

    uint32_t address;
    if(index == 0) {
        address = UPGRADE_INFO_1_ADDRESS;
    } else if(index == 1) {
        address = UPGRADE_INFO_2_ADDRESS;
    } else if(index == 2) {
        address = UPGRADE_INFO_3_ADDRESS;
    }
    GD25Qxx_Read((uint8_t*)upgrade, address, sizeof(Upgrade_t));

//	if(upgrade->info_crc != DM_crc((uint8_t*)(&upgrade + 4), sizeof(Upgrade_t) - 4)) {
//		return UPGRADE_STATUS_INFO_CRC;
//	}

    return UPGRADE_STATUS_SUCCESS;
}

UpgradeStatus DM_write_upgrade_info(Upgrade_t *upgrade, uint8_t index) {
    if(index > 2) {
        return UPGRADE_STATUS_OUT_INDEX;
    }

    uint32_t info_address;
    if(index == 0) {
        info_address = UPGRADE_INFO_1_ADDRESS;
    } else if(index == 1) {
        info_address = UPGRADE_INFO_2_ADDRESS;
    } else if(index == 2) {
        info_address = UPGRADE_INFO_3_ADDRESS;
    }

    // ���� info����
    GD25Qxx_EraseSector(info_address);
    // д�� info����
    upgrade->info_crc = DM_crc((uint8_t*)upgrade + 4, sizeof(Upgrade_t) - 4);
    GD25Qxx_Write((uint8_t*)upgrade, info_address, sizeof(Upgrade_t));

    return UPGRADE_STATUS_SUCCESS;
}

UpgradeStatus DM_erase_upgrade_bin(uint8_t index) {
    if(index > 2) {
        return UPGRADE_STATUS_OUT_INDEX;
    }

    uint32_t address;
    if(index == 0) {
        address = UPGRADE_BIN_1_ADDRESS;
    } else if(index == 1) {
        address = UPGRADE_BIN_2_ADDRESS;
    } else if(index == 2) {
        address = UPGRADE_BIN_3_ADDRESS;
    }

    // ���� data����
    uint32_t cnt = UPGRADE_BIN_SIZE / 4096;
    for(uint32_t i = 0; i < cnt; i++) {
        uint32_t sector_addr = address + i * 4096;
        //GD25Qxx_erase_sector(sector_num);

        uint8_t retry = 0;
        uint8_t erase_success = 0;

        while(retry < 3 && !erase_success) {
            // ��������
            GD25Qxx_EraseSector(sector_addr);

            // �ȴ��������
            delay_1ms(10);

            // ����Ƿ�ȫΪ0xFF������״̬��
            erase_success = 1;
			uint8_t verify;
			for(uint16_t j =0; j < 4096; j++) {
				GD25Qxx_Read(&verify, sector_addr + j, 1);
				if(verify != 0xFF) {
					erase_success = 0;
					break;
				}
			}

            if(!erase_success) {
                retry++;
                delay_1ms(20); // ����ǰ�ȴ�����ʱ��
            }
        }

        if(!erase_success) {
            return UPGRADE_STATUS_BIN_ERASE_ERROR;
        }
    }
    return UPGRADE_STATUS_SUCCESS;
}


UpgradeStatus DM_write_upgrade_bin(uint8_t index, uint32_t offset, uint8_t* data, uint8_t len) {
    if(index > 2) {
        return UPGRADE_STATUS_OUT_INDEX;
    }

    uint32_t address;
    if(index == 0) {
        address = UPGRADE_BIN_1_ADDRESS;
    } else if(index == 1) {
        address = UPGRADE_BIN_2_ADDRESS;
    } else if(index == 2) {
        address = UPGRADE_BIN_3_ADDRESS;
    }
    address += offset;

	if(address % 4096 == 0) {
		// ������ʼ����������
		GD25Qxx_EraseSector(address);
	}
	
	GD25Qxx_Write(data, address, len);
	
	////////// ������������Ҫɾ�� ////////
	printf("WRITE %08X: ", address);
	for(uint8_t i = 0; i < len; i++) {
		printf("%02X ", data[i]);
	}
	printf("\r\n");

		
	uint8_t tmp[len];
	uint8_t flag = 0;
	GD25Qxx_Read(tmp, address, len);
	for(uint8_t i = 0; i < len; i++) {
		if(data[i] != tmp[i]) {
			flag = 1;
            break;
        }
	}
	
//	printf("READ  %08X: ", address);
//	for(uint8_t i = 0; i < len; i++) {
//		printf("%02X ", tmp[i]);
//	}
//	printf("\r\n");
	
	if(flag) {
        return UPGRADE_STATUS_BIN_WRITE_ERROR;
    }
    return UPGRADE_STATUS_SUCCESS;
}
