./objects/task.o: ..\User\Task.c ..\User\Task.h ..\App\App.h \
  ..\BSP\board_config.h C:\keil5\ARM\ARMCLANG\include\stdio.h \
  ..\User\Log.h C:\keil5\ARM\ARMCLANG\include\string.h \
  ..\Libraries\lib_peripherals.h ..\Libraries\usart\lib_usart.h \
  ..\Libraries\usart\Usart_config.h \
  ..\Libraries\usart\..\gpio\lib_gpio.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Include\gd32f3x0.h \
  C:\keil5\ARM\CMSIS\5.9.0\CMSIS\Core\Include\core_cm4.h \
  C:\keil5\ARM\ARMCLANG\include\stdint.h \
  C:\keil5\ARM\CMSIS\5.9.0\CMSIS\Core\Include\cmsis_version.h \
  C:\keil5\ARM\CMSIS\5.9.0\CMSIS\Core\Include\cmsis_compiler.h \
  C:\keil5\ARM\CMSIS\5.9.0\CMSIS\Core\Include\cmsis_armclang.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Include\system_gd32f3x0.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Include\gd32f3x0_libopt.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_adc.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_crc.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_ctc.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_dbg.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_dma.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_exti.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_fmc.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_gpio.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_syscfg.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_i2c.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_fwdgt.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_pmu.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_rcu.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_rtc.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_spi.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_timer.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_usart.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_wwdgt.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_misc.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_tsi.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_cec.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_cmp.h \
  C:\keil5\GigaDevice\GD32F3x0_DFP\3.2.1\Device\Firmware\Peripherals\inc\gd32f3x0_dac.h \
  ..\Libraries\usart\lib_usart0.h ..\Libraries\i2c\lib_i2c.h \
  ..\Libraries\i2c\I2C_config.h ..\Libraries\i2c\..\gpio\lib_gpio.h \
  ..\Libraries\i2c\lib_i2c1.h ..\Libraries\spi\lib_spi.h \
  ..\Libraries\spi\SPI_config.h ..\Libraries\spi\..\gpio\lib_gpio.h \
  ..\Libraries\spi\lib_spi0.h ..\Libraries\timer\lib_timer.h \
  ..\Libraries\timer\Timer_config.h \
  ..\Libraries\timer\..\gpio\lib_gpio.h ..\Libraries\timer\lib_timer5.h \
  ..\Libraries\adc\lib_adc.h ..\Libraries\adc\ADC_config.h \
  ..\Libraries\adc\..\gpio\lib_gpio.h ..\User\systick.h \
  ..\Libraries\fmc\lib_fmc.h ..\Libraries\fmc\FMC_config.h \
  ..\Libraries\fmc\..\gpio\lib_gpio.h \
  ..\Libraries\common\circular_queue.h \
  C:\keil5\ARM\ARMCLANG\include\stdbool.h \
  C:\keil5\ARM\ARMCLANG\include\stdlib.h ..\App\DataManage.h
