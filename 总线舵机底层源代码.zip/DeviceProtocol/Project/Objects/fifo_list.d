./objects/fifo_list.o: ..\Libraries\common\fifo_list.c \
  ..\Libraries\common\fifo_list.h C:\keil5\ARM\ARMCLANG\include\stddef.h \
  C:\keil5\ARM\ARMCLANG\include\stdlib.h \
  C:\keil5\ARM\ARMCLANG\include\stdio.h
