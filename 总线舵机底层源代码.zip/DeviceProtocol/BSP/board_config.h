#ifndef __BOARD_CONFIG_H__
#define __BOARD_CONFIG_H__

#include <stdio.h>
#include "Log.h"
#include "lib_peripherals.h"


#define TEST_MODE	0



//// �̼��汾
#define MAJOR_VERSION	0
#define MINOR_VERSION	1

//// ����ͺ�
#define MOTOR_TYPE		1


//// 1. �ű�����
//// 2. Flash
//// 3. �¶ȴ�����
//// 4. �������
//// 5. ��ѹ���
//// 6. �������
//// 7. �����������
//// 8. LED��ʾ



///////////////////////////// Device UUID ////////////////////
#define MCU_ID_1	(*(volatile uint32_t *)(uint32_t)(0x1FFFF7E0))
#define MCU_ID_2	(*(volatile uint32_t *)(uint32_t)(0x1FFFF7AC))
#define MCU_ID_3	(*(volatile uint32_t *)(uint32_t)(0x1FFFF7B4))		


///////////////////////////// AS5600 /////////////////////////
#define AS5600_ADDR							0x36
#define AS5600_WRITE(addr, reg, data, len)	lib_i2c1_write_sync(addr, reg, data, len)
#define AS5600_READ(addr, reg, data, len)	lib_i2c1_read_sync(addr, reg, data, len)

//////////////////////////// GD25Qxx Flash ///////////////////////////
#define GD25Qxx_CS_RCU		RCU_GPIOA
#define GD25Qxx_CS_PIN		GPIOA, GPIO_PIN_4

#define GD25Qxx_CS_INIT()	lib_io_pp_pu(GD25Qxx_CS_RCU, GD25Qxx_CS_PIN)
#define GD25Qxx_CS(val)		lib_io_write(GD25Qxx_CS_PIN, val)

#define GD25Qxx_RW(dat)		lib_spi0_write_read(dat)

//////////////////////////// LED //////////////////////////////////////////
#define LED_INIT()			lib_io_pp(RCU_GPIOB, GPIOB, GPIO_PIN_6)
#define LED_on()			lib_io_write(GPIOB, GPIO_PIN_6, 1)
#define LED_off()			lib_io_write(GPIOB, GPIO_PIN_6, 0)


////////////////////////// Temperature ////////////////////////////////////
// ADC in3 PA3
#define TEMPERATURE_SAMPLE_TIME		50
//#define TEMPERATURE_GET_VALUE()		lib_adc_get(ADC_CHANNEL_3)
#define TEMPERATURE_GET_VALUE()		lib_adc_get(ADC_CHANNEL_16)

////////////////////////// Voltage ////////////////////////////////////////
// ADC in9 PB1
#define VOLTAGE_SAMPLE_TIME			50
#define VOLTAGE_GET_VALUE()			lib_adc_get(ADC_CHANNEL_9)

////////////////////////// Current ////////////////////////////////////////
// ADC in2 PA2
#define CURRENT_SAMPLE_TIME			50
#define CURRENT_GET_VALUE()			lib_adc_get(ADC_CHANNEL_2)


////////////////////////// Motor ////////////////////////////////////////
#define SW_RCU		RCU_GPIOB
#define SW_PIN		GPIOB, GPIO_PIN_4
#define SW_ON()		lib_io_write(SW_PIN, 1)
#define SW_OFF()	lib_io_write(SW_PIN, 0)






#endif