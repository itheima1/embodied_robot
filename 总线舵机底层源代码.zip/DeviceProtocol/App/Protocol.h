#ifndef __PROTOCOL_H__
#define __PROTOCOL_H__


#include "board_config.h"
#include "stdlib.h"
#include "DataManage.h"
#include "Task.h"


///////////////////////////// Э��Ļ�������////////////////
void Protocol_init();

//��������
void Protocol_recv_one(uint8_t value);
void Protocol_recv_more(uint8_t *value, uint16_t len);

void Protocol_parse();
//////////////////////////////////////////////////////////


#endif