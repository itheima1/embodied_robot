#ifndef __APP_H__
#define __APP_H__

#include "board_config.h"
#include <stdio.h>

#include "DataManage.h"


extern R_Data_t 	g_r_data;
extern RW_Data_t 	g_rw_data;
extern RWS_Data_t 	g_rws_data;


#if TEST_MODE

#define App_init()	App_test_init()

////////////////////// TEST /////////////////
void App_test_init();

void App_test_angle_scan_task();
void App_test_flash_task();
void App_test_parse_task();

#else

extern uint8_t 	g_led_state;



#define App_init()		App_servo_init()

void App_servo_init();

void App_led_task();
void App_protocol_parse_task();
void App_position_scan_task();
void App_temperature_scan_task();
void App_voltage_scan_task();
void App_current_scan_task();

void test_upgrade_data_task();

void App_restart_task();

#endif


#endif