#ifndef __DATA_MANAGE_H__
#define __DATA_MANAGE_H__

#include "board_config.h"

//#define UPGRADE_STATE_NORMAL		0
//#define UPGRADE_STATE_DOWNLOADING	1
//#define UPGRADE_STATE_CHECK_CRC		2
//#define UPGRADE_STATE_BACKUP		3
//#define UPGRADE_STATE_UPGRADING		4

#define UPGRADE_FLAG_NONE				0xFF
#define UPGRADE_FLAG_OFF				0x00
#define UPGRADE_FLAG_ON					0x01

typedef enum {
	BOOT_STATUS_SUCCESS = 0, 
	BOOT_STATUS_ERASE_ERR,
	BOOT_STATUS_WRITE_ERR,
	BOOT_STATUS_INFO_CRC
} BootStatus;

typedef struct __attribute__((packed)){
	uint32_t	crc;
	uint8_t		upgrade_flag;			// ���±��
	uint8_t		download_state;			// ����״̬
	uint32_t	current_app_address;	// ��ǰAPP�����FLASH�еĵ�ַ
	uint8_t		current_app_index;		// ��ǰAPP�����FLASH�е����
} Boot_t;


// read only data
typedef struct __attribute__((packed)) {
	uint32_t 	uuid;
	uint16_t 	version;
	uint8_t		motor_type;
	uint16_t	current_position;
	uint16_t	current_speed;
	uint16_t	current_load;
	uint8_t		current_voltage;
	uint16_t	current_current;
	uint8_t		current_temperature;
} R_Data_t;

// read write data
typedef struct __attribute__((packed)) {
	uint8_t 	torque_enable;
	uint16_t 	target_position;
} RW_Data_t;

// read write store data
typedef struct __attribute__((packed)) {
	uint8_t		ID;
	uint16_t	min_position;
	uint16_t	max_position;
	uint16_t	position_offset;
	uint8_t		max_voltage;
	uint8_t		min_voltage;
	uint8_t		max_temperature;
	uint16_t	max_current;
	uint8_t		kp;
	uint8_t		ki;
	uint8_t		kd;
} RWS_Data_t;




void DM_init();

void DM_reload();

uint32_t DM_crc(uint8_t* buffer, uint32_t len);

void DM_store(uint32_t address, uint16_t len);

void DM_read_from_index(uint8_t index, uint8_t* data, uint8_t data_len);
uint8_t DM_write_to_index(uint8_t index, uint8_t* data, uint8_t data_len);
uint8_t DM_store_to_index(uint8_t index, uint8_t* data, uint8_t data_len);

BootStatus DM_read_boot(Boot_t *boot);
BootStatus DM_write_boot(Boot_t *boot);

void DM_restore();

uint8_t DM_set_upgrade();

#endif