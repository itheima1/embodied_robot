#include "DataManage.h"

#include "bsp_gd25qxx.h"

/************************/
/************************/
/* FMC
|---------------|---------------|---------------|-----------|
|	����		|	��ʼλ��		|	����λ��		|	��С	|
|---------------|---------------|---------------|-----------|
|	BOOTLOADER	|	0x0800 0000	|	0x0800 4FFF	|	20K		|
|---------------|---------------|---------------|-----------|
|  Meta	Info	|	0x0800 5000	|	0x0800 5400	|	1K		|
|---------------|---------------|---------------|-----------|
|  APPLICATION	|	0x0800 5400	|				|			|
|---------------|---------------|---------------|-----------|
*/
/*
Flash Data Info
|---------------|---------------|---------------|-----------|
|	����		|	��ʼλ��		|	����λ��		|	��С	|
|---------------|---------------|---------------|-----------|
| UPGRADE INFO1	|	0x0000 0000	|	0x0000 0FFF	|	4K		|
|---------------|---------------|---------------|-----------|
| UPGRADE BIN1	|	0x0000 1000	|	0x0001 BFFF	|	44K		|
|---------------|---------------|---------------|-----------|
| UPGRADE INFO2	|	0x0000 C000	|	0x0000 CFFF	|	4K		|
|---------------|---------------|---------------|-----------|
| UPGRADE BIN2	|	0x0000 D000	|	0x0001 7FFF	|	44K		|
|---------------|---------------|---------------|-----------|
| UPGRADE INFO2	|	0x0001 8000	|	0x0001 8FFF	|	4K		|
|---------------|---------------|---------------|-----------|
| UPGRADE BIN2	|	0x0001 9000	|	0x0002 3FFF	|	44K		|
|---------------|---------------|---------------|-----------|
|  APP Config	|	0x0002 4000	|	0x0002 4FFF	|	4K		|
|---------------|---------------|---------------|-----------|
|  APP Config	|	0x0002 5000	|	0x0002 5FFF	|	4K		|
|---------------|---------------|---------------|-----------|
*/

#define BOOT_ADDRESS					((uint32_t)0x08005000)

#define CHECK_RWS_INIT_ADDRESS			((uint32_t)0x00024000)
#define RWS_BASE_ADDRESS				((uint32_t)0x00025000)


R_Data_t 	g_r_data;
RW_Data_t 	g_rw_data;
RWS_Data_t 	g_rws_data;

static uint32_t r_data_address;
static uint32_t rw_data_address;
static uint32_t rws_data_address;
static uint32_t rws_data_store_address;
static RWS_Data_t 	g_rws_data_store;

void DM_init() {
	// ��ʼ���־û��洢
	GD25Qxx_Init();
	
	uint32_t kb = GD25Qxx_GetCapacityKB();
	printf("kb: %d\r\n", kb);
	
	////////////////////// ��ʼ��ֻ������(ֻ�洢���ڴ��У�����ʱ���м�����)
	uint32_t id1 = MCU_ID_1;
	uint32_t id2 = MCU_ID_2;
	uint32_t id3 = MCU_ID_3;
	
	printf("id1: %08X\r\n", id1);
	printf("id2: %08X\r\n", id2);
	printf("id3: %08X\r\n", id3);
	
	uint8_t data[12];
	memcpy(&data[0], &id1, 4);
	memcpy(&data[4], &id2, 4);
	memcpy(&data[8], &id3, 4);
	
	g_r_data.uuid = DM_crc(data, 12);
	printf("uuid: %d 0x%08X\r\n", g_r_data.uuid, g_r_data.uuid);
	
	g_r_data.version 		= (MAJOR_VERSION << 8) | MINOR_VERSION;
	
	g_r_data.motor_type 			= MOTOR_TYPE;
	g_r_data.current_position 		= 0;
	g_r_data.current_speed			= 0;
	g_r_data.current_load			= 0;
	g_r_data.current_voltage		= 0;
	g_r_data.current_current		= 0;
	g_r_data.current_temperature 	= 0;
	
	///////////////////// ��ʼ����д����(ֻ�洢���ڴ��У��û����õ�����)
	g_rw_data.target_position 	= 0; // Ĭ��ֵΪ 0
	g_rw_data.torque_enable 	= 0; // Ĭ��ֵΪ 0
	
	///////////////////// ��ʼ����д������(�洢��Flash��)
	uint8_t rws_init_flag = 0xFF;
	GD25Qxx_Read(&rws_init_flag, CHECK_RWS_INIT_ADDRESS, 1);

	if(rws_init_flag == 0xFF) {		
		
		g_rws_data.ID 				= 1;
		g_rws_data.min_position		= 0;
		g_rws_data.max_position		= 4095;
		g_rws_data.position_offset	= 0;
		g_rws_data.max_voltage		= 80;
		g_rws_data.min_voltage		= 50;
		g_rws_data.max_temperature	= 80;
		g_rws_data.max_current		= 500;
		g_rws_data.kp				= 10;
		g_rws_data.ki				= 1;
		g_rws_data.kd				= 5;
		
		rws_init_flag = 0;
		
		GD25Qxx_EraseSector(CHECK_RWS_INIT_ADDRESS);
		GD25Qxx_Write(&rws_init_flag, CHECK_RWS_INIT_ADDRESS, 1);
		
		GD25Qxx_EraseSector(RWS_BASE_ADDRESS);
		GD25Qxx_Write((uint8_t *)&g_rws_data, RWS_BASE_ADDRESS, sizeof(RWS_Data_t));
	}
	DM_reload();
	
//	LOG_DEBUG("Flag:            %d", rws_init_flag);
//	LOG_DEBUG("ID:              %d", g_rws_data.ID);
//	LOG_DEBUG("min_position:    %d", g_rws_data.min_position);
//	LOG_DEBUG("max_position:    %d", g_rws_data.max_position);
//	LOG_DEBUG("position_offset: %d", g_rws_data.position_offset);
//	LOG_DEBUG("max_voltage:     %d", g_rws_data.max_voltage);
//	LOG_DEBUG("min_voltage:     %d", g_rws_data.min_voltage);
//	LOG_DEBUG("max_temperature: %d", g_rws_data.max_temperature);
//	LOG_DEBUG("max_current:     %d", g_rws_data.max_current);
//	LOG_DEBUG("KP:              %d", g_rws_data.kp);
//	LOG_DEBUG("KI:              %d", g_rws_data.ki);
//	LOG_DEBUG("KD:              %d", g_rws_data.kd);
	
	// �ڴ��еĻ���ַ
	r_data_address = (uint32_t)&g_r_data;
	rw_data_address = (uint32_t)&g_rw_data;
	rws_data_address = (uint32_t)&g_rws_data;
	rws_data_store_address = (uint32_t)&g_rws_data_store;
}

void DM_reload() {
	GD25Qxx_Read((uint8_t *)&g_rws_data, RWS_BASE_ADDRESS, sizeof(RWS_Data_t));
	GD25Qxx_Read((uint8_t *)&g_rws_data_store, RWS_BASE_ADDRESS, sizeof(RWS_Data_t));
}


void DM_store(uint32_t address, uint16_t len) {
	uint32_t offset = address - rws_data_address;
	
	uint32_t store_ram_address = rws_data_store_address + offset;
	
	uint8_t* value = (uint8_t *)address;
	uint8_t* ptr = (uint8_t *)store_ram_address;
	for(uint8_t i = 0; i < len; i++) {
		ptr[i] = value[i];
	}
	
	GD25Qxx_EraseSector(RWS_BASE_ADDRESS);
	GD25Qxx_Write((uint8_t*)&g_rws_data_store, RWS_BASE_ADDRESS, sizeof(RWS_Data_t)); 
}

void DM_read_from_index(uint8_t index, uint8_t* data, uint8_t data_len) {

	if(index < 50) {
		// read from read only
		uint8_t* value = (uint8_t*)(r_data_address + index);
		for(uint8_t i = 0; i < data_len; i++) {
			data[i] = value[i];
		}
	} else if(index < 70) {
		// read from read write
		uint8_t* value = (uint8_t*)(rw_data_address + (index - 50));
		for(uint8_t i = 0; i < data_len; i++) {
			data[i] = value[i];
		}
	} else {
		// read from read write store
		uint8_t* value = (uint8_t*)(rws_data_address + (index - 70));
		for(uint8_t i = 0; i < data_len; i++) {
			data[i] = value[i];
		}
	}
}

uint8_t DM_write_to_index(uint8_t index, uint8_t* data, uint8_t data_len) {
	if(index >= 50 && index + data_len <= 53) {
		uint8_t* ptr = (uint8_t*)(rw_data_address + (index - 50));
		for(uint8_t i = 0; i < data_len; i++) {
			ptr[i] = data[i];
		}
		return 1;
	} else if(index >= 70 && index + data_len <= 85) {
		uint8_t* ptr = (uint8_t*)(rws_data_address + (index - 70));
		for(uint8_t i = 0; i < data_len; i++) {
			ptr[i] = data[i];
		}
		return 1;
	}
	return 0;
}

uint8_t DM_store_to_index(uint8_t index, uint8_t* data, uint8_t data_len) {
	if(index >= 70 && index + data_len <= 85) {
		uint8_t* ptr1 = (uint8_t*)(rws_data_address + (index - 70));
		uint8_t* ptr2 = (uint8_t*)(rws_data_store_address + (index - 70));
		for(uint8_t i = 0; i < data_len; i++) {
			ptr1[i] = data[i];
			ptr2[i] = data[i];
		}
		// ���� RWS����
		GD25Qxx_EraseSector(RWS_BASE_ADDRESS);
		GD25Qxx_Write((uint8_t*)&g_rws_data_store, RWS_BASE_ADDRESS, sizeof(RWS_Data_t)); 
		return 1;
	}
	return 0;
}

void DM_restore() {
	g_rws_data_store = g_rws_data;
	GD25Qxx_EraseSector(RWS_BASE_ADDRESS);
	GD25Qxx_Write((uint8_t*)&g_rws_data_store, RWS_BASE_ADDRESS, sizeof(RWS_Data_t)); 
}

uint32_t DM_crc(uint8_t* buffer, uint32_t len) {

    // 1. ��ʼ�� CRC ��Ԫ
    rcu_periph_clock_enable(RCU_CRC);            // ���� CRC ��Ԫʱ��
    crc_deinit();                               // ȷ�� CRC ��Ԫ���ڳ�ʼ״̬
    crc_data_register_reset();                  // ���� CRC ���ݼĴ���

    // 2. ���� CRC ��ʼֵ����׼ CRC-32 ��ʼֵ��
    uint32_t initial_value = 0;        // CRC-32 ��ʼֵ
    crc_init_data_register_write(initial_value);
	uint8_t data_format = INPUT_FORMAT_BYTE;

	crc_block_data_calculate(buffer, len, data_format);

    // 4. ��ȡ���յ� CRC ���
    uint32_t final_crc_result = crc_data_register_read();
    final_crc_result ^= 0xFFFFFFFF;
	return final_crc_result;
}

BootStatus DM_read_boot(Boot_t *boot) {
//	GD25Qxx_read((uint8_t *)boot, BOOT_ADDRESS, sizeof(Boot_t));
	lib_fmc_read(BOOT_ADDRESS, (uint8_t *)boot, sizeof(Boot_t));
	
	// 启用CRC校验并修复指针错误
	if(boot->crc != DM_crc((uint8_t *)&boot->upgrade_flag, sizeof(Boot_t) - sizeof(uint32_t))) {
		return BOOT_STATUS_INFO_CRC;
	}
	
	return BOOT_STATUS_SUCCESS;
}

BootStatus DM_write_boot(Boot_t *boot) {	
	if(lib_fmc_erase(BOOT_ADDRESS, sizeof(Boot_t))){
		return BOOT_STATUS_ERASE_ERR;
	}
	
	// 修复指针错误：应该跳过crc字段（4字节），计算从upgrade_flag开始的数据
	boot->crc = DM_crc((uint8_t *)&boot->upgrade_flag, sizeof(Boot_t) - sizeof(uint32_t));
	if(lib_fmc_write(BOOT_ADDRESS, (uint8_t*)boot, sizeof(Boot_t))) {
		return BOOT_STATUS_WRITE_ERR;
	}
	return BOOT_STATUS_SUCCESS;
}


uint8_t DM_set_upgrade() {
	Boot_t boot;
	if(BOOT_STATUS_SUCCESS != DM_read_boot(&boot)) {
		
		// 修复指针错误：应该计算从upgrade_flag开始的数据
		uint32_t crc = DM_crc((uint8_t *)&boot.upgrade_flag, sizeof(Boot_t) - sizeof(uint32_t));
		LOG_INFO("crc: %0X8  %0X8", boot.crc, crc);
		LOG_INFO("address: %0X8", boot.current_app_address);
		LOG_INFO("index: %d", boot.current_app_index);
		LOG_INFO("state: %d", boot.download_state);
		LOG_INFO("flag: %d", boot.upgrade_flag);
		
		boot.current_app_address = 0xD0000;
		crc = DM_crc((uint8_t *)&boot.upgrade_flag, sizeof(Boot_t) - sizeof(uint32_t));
		LOG_INFO("crc: %0X8  %0X8", boot.crc, crc);
		
		LOG_INFO("read boot error");
		return 1;
	}
	
	boot.upgrade_flag = UPGRADE_FLAG_ON;
	BootStatus status = DM_write_boot(&boot);
	
	if(BOOT_STATUS_SUCCESS == status) {
		return 0;
	}
	LOG_INFO("write boot: %d", status);
	
	return 1;
}
