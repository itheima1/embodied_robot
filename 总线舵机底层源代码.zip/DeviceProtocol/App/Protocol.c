#include "Protocol.h"


#define MAX_DATA_LEN		64



#define MAX_WRITE_PARAM_LEN	24
#define MAX_READ_PARAM_LEN	24


#define FRAME_HEAD 	0xAA
#define FRAME_TAIL 	0xBB

#define RX_CMD_WRITE		0x01
#define RX_CMD_STORE		0x02
#define RX_CMD_READ			0x03
#define RX_CMD_OTA_TAG		0x10


#define SUCCESS						0x00
#define ERR_WRITE_PARAM_OUT_LEN		0x10
#define ERR_READ_PARAM_FORMAT		0x11
#define ERR_READ_PARAM_OUT_LEN		0x12
#define ERR_OTA_TAG					0x13
#define ERR_ID_OUT_OF_RANGE			0x14




#define QUEUE_LEN	512

extern R_Data_t 	g_r_data;
extern RW_Data_t 	g_rw_data;
extern RWS_Data_t 	g_rws_data;

extern uint8_t 		g_led_state;


static CQ_Queue rx_queue;


static uint8_t	 b_cmd;
static uint8_t*  b_tmp;
static uint8_t	 b_len;
static uint8_t	 b_pre = 255;


union floatToBytes {
    float f;
    unsigned char bytes[4];
};

union intToBytes {
    uint32_t i;
    unsigned char bytes[4];
};

union shortToBytes {
    uint16_t s;
    unsigned char bytes[2];
};


static void int_to_bytes(uint32_t value, uint8_t* bytes) {
    union intToBytes converter;
    converter.i = value;

    bytes[0] = converter.bytes[0];
    bytes[1] = converter.bytes[1];
    bytes[2] = converter.bytes[2];
    bytes[3] = converter.bytes[3];
}

static uint32_t bytes_to_int(uint8_t* bytes) {
    union intToBytes converter;

    converter.bytes[0] = bytes[0];
    converter.bytes[1] = bytes[1];
    converter.bytes[2] = bytes[2];
    converter.bytes[3] = bytes[3];

    return converter.i;
}

static void short_to_bytes(uint16_t value, uint8_t* bytes) {
    union shortToBytes converter;
    converter.s = value;

    bytes[0] = converter.bytes[0];
    bytes[1] = converter.bytes[1];
}

static uint16_t bytes_to_short(uint8_t* bytes) {
    union shortToBytes converter;

    converter.bytes[0] = bytes[0];
    converter.bytes[1] = bytes[1];

    return converter.s;
}


void Protocol_init() {
    CQ_Init(&rx_queue, QUEUE_LEN);
}

uint8_t check_sum(uint8_t *buff, uint8_t len) {
    uint16_t sum = 0;
    // 计算ID + CMD + LEN + DATA的校验和，跳过帧头(2字节)和帧尾(1字节)和校验位(1字节)
    for(uint8_t i = 2; i < len - 2; i++) {
        sum += buff[i];
    }
    return (uint8_t)(sum & 0xFF);
}


void Protocol_recv_one(uint8_t value) {
    CQ_Enqueue(&rx_queue, value);
}

void Protocol_recv_more(uint8_t *data, uint16_t len) {
    CQ_EnqueueList(&rx_queue, data, len);
}


static void response_device_error(uint8_t id, uint8_t cmd, uint8_t error_code) {
    uint8_t buff[8];
    buff[0] = FRAME_HEAD;
    buff[1] = FRAME_HEAD;
    buff[2] = id | 0x80;
    buff[3] = cmd;
    buff[4] = 1;
    buff[5] = error_code;
    buff[6] = check_sum(buff, 8);
    buff[7] = FRAME_TAIL;
    lib_usart0_send_data(buff, 8);
}

static void response_device_data(uint8_t id, uint8_t cmd, uint8_t* data, uint8_t len) {
    uint8_t buff[7 + len];
    buff[0] = FRAME_HEAD;
    buff[1] = FRAME_HEAD;
    buff[2] = id | 0x80;
    buff[3] = cmd;
    buff[4] = len;
    for(uint8_t i = 0; i < len; i++) {
        buff[5 + i] = data[i];
    }
    buff[5 + len] = check_sum(buff, 7 + len);
    buff[6 + len] = FRAME_TAIL;
    lib_usart0_send_data(buff, 7 + len);
}


static void response_broadcast_data(uint8_t cmd, uint8_t* data, uint8_t len) {
    uint8_t buff[7 + len];
    buff[0] = FRAME_HEAD;
    buff[1] = FRAME_HEAD;
    buff[2] = 0xFF;
    buff[3] = cmd;
    buff[4] = len;
    for(uint8_t i = 0; i < len; i++) {
        buff[5 + i] = data[i];
    }
    buff[5 + len] = check_sum(buff, 7 + len);
    buff[6 + len] = FRAME_TAIL;
    lib_usart0_send_data(buff, 7 + len);
}

static void response_ota_error(uint32_t mac, uint8_t cmd, uint8_t error_code) {
    uint8_t buff[12];
    buff[0] = FRAME_HEAD;
    buff[1] = FRAME_HEAD;
    buff[2] = 0xFD;
    buff[3] = cmd;
    buff[4] = 5;
	int_to_bytes(mac, &buff[5]);
    buff[9] = error_code;
    buff[10] = check_sum(buff, 12);
    buff[11] = FRAME_TAIL;
    lib_usart0_send_data(buff, 12);
}

static void response_scan_mac(uint8_t cmd, uint32_t mac, uint8_t id) {
	uint8_t buff[12];
	buff[0] = FRAME_HEAD;
    buff[1] = FRAME_HEAD;
	buff[2] = 0xFE;
    buff[3] = cmd;
	buff[4] = 5;
	int_to_bytes(mac, &buff[5]);
	buff[9] = id;
	buff[10] = check_sum(buff, 12);
	buff[11] = FRAME_TAIL;
	lib_usart0_send_data(buff, 12);
}

static void response_scan_error(uint32_t mac, uint8_t cmd, uint8_t error_code) {
    uint8_t buff[12];
    buff[0] = FRAME_HEAD;
    buff[1] = FRAME_HEAD;
    buff[2] = 0xFE;
    buff[3] = cmd;
    buff[4] = 5;
	int_to_bytes(mac, &buff[5]);
    buff[9] = error_code;
    buff[10] = check_sum(buff, 12);
    buff[11] = FRAME_TAIL;
    lib_usart0_send_data(buff, 12);
}

static void do_work(uint8_t *buff, uint8_t len) {
    // ����Э��ɻ�
    uint8_t id = buff[2];
    uint8_t cmd = buff[3];

    if(id >=0 && id <= 120) {
        // ָ���豸��Ϣ
        if(id != g_rws_data.ID) {
            // ���Ǹ���ǰ�豸������Ϣ
            return;
        }

        if(cmd == RX_CMD_WRITE || cmd == RX_CMD_STORE) {
            // ��ʱд ���� �־�д��������ʽ��ͬ
            uint8_t data_len = buff[4];

            if(data_len > MAX_WRITE_PARAM_LEN) {
                // ����д��������
                response_device_error(id, cmd, ERR_WRITE_PARAM_OUT_LEN);
                return;
            }

            uint8_t cnt = 0;
            while(cnt < data_len) {
                uint8_t address = buff[5 + cnt];
                uint8_t value_len = buff[6 + cnt];

                // ��ҪУ���Ƿ��ںϷ����� TODO:
                if(cmd == RX_CMD_WRITE) {
                    DM_write_to_index(address, &buff[7 + cnt], value_len);
                } else if(cmd == RX_CMD_STORE) {
                    DM_store_to_index(address, &buff[7 + cnt], value_len);
                }

                cnt += 2;
                cnt += value_len;
            }

            response_device_error(id, cmd, SUCCESS);
        } else if(cmd == RX_CMD_READ) {
            // ������
            uint8_t data_len = buff[4];

            if(data_len % 2 != 0) {
                // ��ȡ��ʽ����ȷ
                response_device_error(id, cmd, ERR_READ_PARAM_FORMAT);
                return;
            }

            uint16_t total = 0;
            for(uint8_t i = 0; i < data_len; i += 2) {
                uint8_t address = buff[5 + i];
                uint8_t len = buff[5 + i + 1];
                total += 1;
                total += len;
            }

            if(total > MAX_READ_PARAM_LEN) {
                // ������ȡ������
                response_device_error(id, cmd, ERR_WRITE_PARAM_OUT_LEN);
                return;
            }

            uint8_t *tmp = malloc(total);
            uint8_t cnt = 0;
            for(uint8_t i = 0; i < data_len; i += 2) {
                uint8_t address = buff[5 + i];
                uint8_t len = buff[5 + i + 1];

                tmp[cnt++] = address;
                DM_read_from_index(address, &tmp[cnt], len);
                cnt += len;
            }
            response_device_data(id, cmd, tmp, total);
            free(tmp);
        }
    } else if(id == 0x7F) {
        // �㲥��Ϣ������������
        if(cmd == RX_CMD_READ) {
            uint8_t flag = 1;

            uint8_t data_len = buff[4];
            uint8_t device_len = buff[5];
            for(uint8_t i = 0; i < device_len; i++) {
                if(buff[6 + i] == g_rws_data.ID) {
                    flag = 0;
                    break;
                }
                b_pre = buff[6 + i];
            }

            if(flag) {
                // û�и��Լ��㲥
                b_pre = 255;
                return;
            }

            // �Լ��ǵ�һ�������̻ظ���Ϣ
            uint16_t total = 0;
            for(uint8_t i = 0; i < data_len - device_len - 1; i += 2) {
                uint8_t address = buff[6 + device_len + i];
                uint8_t len = buff[6 + device_len + i + 1];
                total += 1;
                total += len;
            }

            if(total > MAX_READ_PARAM_LEN) {
                // ������ȡ������
                b_cmd = cmd;
                b_tmp = malloc(2);
                b_len = 2;
                b_tmp[0] = g_rws_data.ID;
                b_tmp[1] = ERR_READ_PARAM_OUT_LEN;

                if(b_pre == 255) {
                    // ��ǰ�ǵ�һ������������
                    response_broadcast_data(b_cmd, b_tmp, b_len);
                    free(b_tmp);
                }

                return;
            }

            b_cmd = cmd;
            b_tmp = malloc(total + 1);
            b_len = total + 1;
            b_tmp[0] = g_rws_data.ID;
            uint8_t cnt = 1;
            for(uint8_t i = 0; i < data_len - device_len - 1; i += 2) {
                uint8_t address = buff[6 + device_len + i];
                uint8_t len = buff[6 + device_len + i + 1];

                b_tmp[cnt++] = address;
                DM_read_from_index(address, &b_tmp[cnt], len);
                cnt += len;
            }

            if(b_pre == 255) {
                // ��ǰ�ǵ�һ������������
                response_broadcast_data(b_cmd, b_tmp, b_len);
                free(b_tmp);
            }
        }
    } else if(id == 0xFF) {
        // �㲥��Ϣ�����Դӻ���
        uint8_t current = buff[5];

        if(current != b_pre) {
            // ��ǰ�㲥���豸����������Լ���¼��ǰһ���豸����ʾ���ֲ����Լ�����Ϣ��
            return;
        }

        response_broadcast_data(b_cmd, b_tmp, b_len);
        free(b_tmp);
        // ����
        b_pre = 255;
    } else if(id == 0x7D) {
		// ota ��Ǹ���
		if(cmd == RX_CMD_OTA_TAG) {
			uint32_t uuid = bytes_to_int(&buff[5]);
			if(uuid != g_r_data.uuid) {
				return;
			}

			if(DM_set_upgrade()) {
				response_ota_error(g_r_data.uuid, cmd, ERR_OTA_TAG);
				return;
			}
			
			// response_ota_error(g_r_data.uuid, cmd, SUCCESS);
			NVIC_SystemReset();
		}
	} else if(id == 0x7E) {
		if(cmd == 0x00) {
			// ɨ����Ϣ
			uint8_t type = buff[5];
			uint8_t h_mac = buff[6];
			uint8_t m_mac = buff[7];
			uint8_t l_mac = buff[8];
			
			if(type == 0x00) {
				// �鿴��8λ
				if(((g_r_data.uuid >> 16) & 0xFF) == h_mac) {
					// ��Ӧ ��ǰ��mac
					response_scan_mac(cmd, g_r_data.uuid, g_rws_data.ID);
				}
			} else if(type == 0x01) {
				// �鿴��8λ����8λ
				if(((g_r_data.uuid >> 16) & 0xFF) == h_mac && ((g_r_data.uuid >> 8) & 0xFF) == m_mac) {
					response_scan_mac(cmd, g_r_data.uuid, g_rws_data.ID);
				}
			} else if(type == 0x02) {
				// �鿴��8λ����8λ����8λ
				if(((g_r_data.uuid >> 16) & 0xFF) == h_mac && ((g_r_data.uuid >> 8) & 0xFF) == m_mac && ((g_r_data.uuid >> 0) & 0xFF) == l_mac) {
					response_scan_mac(cmd, g_r_data.uuid, g_rws_data.ID);
				}
			}	
		} else if(cmd == 0x01) {
			// ����ID
			uint32_t mac = bytes_to_int(&buff[5]);
			if(mac != g_r_data.uuid) {
				return;
			}
			
			uint8_t id = buff[9];
			if(id > 120) {
				response_scan_error(mac, cmd, ERR_ID_OUT_OF_RANGE);
				return;
			}
			
			g_rws_data.ID = id;
			DM_restore();
			
			response_scan_error(mac, cmd, SUCCESS);
		} else if(cmd == 0x02) {
			// ��˸
			uint32_t mac = bytes_to_int(&buff[5]);
			if(mac != g_r_data.uuid) {
				return;
			}
			
			uint8_t state = buff[9];
			g_led_state = state;
		}
	}

}


void Protocol_parse() {
    //�������߼�
    //�ӻ��ζ�����ȡ���ݳ������н���
    // ֡ͷ  ID  ����λ	 ���ݳ���	����λ	У��λ	֡β

    // ֡ͷ ID ����λ ���ݳ���(len)

    /// ���ݳ��ȱ�Ȼ���ڵ���5
    if(CQ_Size(&rx_queue) < 5) return;

    // ֡ͷ
    uint8_t head1;
    CQ_GetElement(&rx_queue, 0, &head1);
    uint8_t head2;
    CQ_GetElement(&rx_queue, 1, &head2);
    if(head1 != FRAME_HEAD || head2 != FRAME_HEAD) {
        CQ_Dequeue(&rx_queue, 0);
        return;// ������ִ��
    }

    // ID
    uint8_t id;
    CQ_GetElement(&rx_queue, 2, &id);

    // ����λ
    uint8_t cmd;
    CQ_GetElement(&rx_queue, 3, &cmd);
//	if(cmd > MAX_CMD_NUM) {
//		CQ_Dequeue(&rx_queue, 0);
//		return;
//	}

    // ���ݳ���
    uint8_t len;
    CQ_GetElement(&rx_queue, 4, &len);
    ////// �費��ҪУ�飬��������Ч��
    /// �����ĵ�����Ҫȥ�ҵ�Э�����������Э�飬
    if(len > MAX_DATA_LEN) {
        CQ_Dequeue(&rx_queue, 0);
        return;
    }

    /// ȷ���ܹ��չ�һ��Э��
    if(len + 7 > CQ_Size(&rx_queue)) {
        // ���ݲ���һ��Э��
        return;
    }

    // ȷ���ܹ���һ��Э��
    // ֡β (У��)
    uint8_t tail;
    CQ_GetElement(&rx_queue, len + 6, &tail);
    if(tail != FRAME_TAIL) {
        //����һ��Э�飬������
        CQ_Dequeue(&rx_queue, 0);
        return;
    }

    // У��λ(У��)
    // �����У��ͣ��Ͷ�����У��λ���бȽϣ���ͬ����һ��Э�飬��ͬ���Ǽٵ�
    uint8_t check;
    CQ_GetElement(&rx_queue, len + 5, &check);
    // ����λ + ���ݳ���λ + ����λ)�Ľ����ȡ��8λ
    uint16_t sum = 0;
    sum += id;
    sum += cmd;
    sum += len;
    // ����λ
    uint8_t data;
    for(uint8_t i = 0; i < len; i++) {
        CQ_GetElement(&rx_queue, 5 + i, &data);
        sum += data;
    }
    sum &= 0xFF;

    if(check != sum) {
        //����һ��Э�飬������
        CQ_Dequeue(&rx_queue, 0);
        return;
    }
	
    ///////////////////// ��Ļ����һ��Э��
    // ����λ
    uint8_t buff[len + 7];

    uint8_t v;
    for(uint8_t i = 0; i < len + 6; i++) {
        CQ_Dequeue(&rx_queue, &v);
        buff[i] = v;
    }
    do_work(buff, len + 7);
}

