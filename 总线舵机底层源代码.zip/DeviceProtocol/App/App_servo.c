#include "App.h"


#include "bsp_AS5600.h"
#include "Protocol.h"
#include "bsp_temperature.h"
#include "bsp_motor_voltage.h"
#include "bsp_motor_current.h"
#include "bsp_motor.h"


uint8_t g_led_state = 1;


void App_servo_init() {
	DM_init();
	Protocol_init();
	
	LED_INIT();
	LED_on();
	
	AS5600_init();
	Temperature_init();
	
	Voltage_init();
	Current_init();
//	Motor_init();
//	Motor_power_off();
	
//	lib_io_pp(RCU_GPIOB, GPIOB, GPIO_PIN_3);
//	lib_io_pp(RCU_GPIOA, GPIOA, GPIO_PIN_15);
//	
//	lib_io_write(GPIOB, GPIO_PIN_3, 0);
//	lib_io_write(GPIOA, GPIO_PIN_15, 1);	
	
}

/////////////////////// Led //////////////////////////////
void App_led_task() {
//  0�� ��ʾ����
//  1�� ��ʾ����
//  2�� ��ʾ200 ms ��˸1��
//  3�� ��ʾ400 ms ��˸1��
//  4�� ��ʾ600 ms ��˸1��
//  5�� ��ʾ800 ms ��˸1��
//  6�� ��ʾ1000 ms ��˸1��
	static uint8_t last_state = 1;
	static uint8_t i = 0;
	static uint8_t flag = 0;
	
	
	if(g_led_state == 0 || g_led_state == 1) {
		if(last_state == g_led_state) return;
		last_state = g_led_state;
		
		if(g_led_state) {
			LED_on();
		} else {
			LED_off();
		}
	} else if(g_led_state > 1 && g_led_state < 7) {
		if(last_state != g_led_state) {
			last_state = g_led_state;
			i = 0;
			flag = 0;
		}
		
		if(i++ >= (g_led_state - 1)) {
			if(flag == 0) {
				flag = 1;
			} else {
				flag = 0;
			}
			i = 0;	
		}
		
		if(flag) {
			LED_on();
		} else {
			LED_off();
		}
	}
}


////////////////////// Position //////////////////////////
void App_position_scan_task() {
	uint16_t position = AS5600_get_position();
	uint16_t offset = g_rws_data.position_offset;
	
	if(position >= offset) {
		g_r_data.current_position = position - offset;
	} else {
		g_r_data.current_position = position + 4096 - offset;
	}
	
//	LOG_DEBUG("position: %d %d\r\n", g_r_data.current_position, offset);	
//	LOG_DEBUG("target: %d\r\n", g_rw_data.target_position);
}

////////////////////// Temperature //////////////////////
void App_temperature_scan_task() {
	Temperature_loop();
}

void Temperature_on_value(uint8_t t) {
	g_r_data.current_temperature = t;
}

///////////////////// Voltage ///////////////////////////
void App_voltage_scan_task() {
	Voltage_loop();
}

void Voltage_on_value(uint8_t v) {
	g_r_data.current_voltage = v;
}

//////////////////// Current ////////////////////////////
void App_current_scan_task() {
	Current_loop();
}

void Current_on_value(uint16_t c) {
	g_r_data.current_current = c;
}


//////////////////// Protocol ////////////////////////////
void lib_usart0_on_recv(uint8_t *data, uint16_t len) {
	Protocol_recv_more(data, len);
}

void App_protocol_parse_task() {
	Protocol_parse();
}

void App_restart_task() {
	NVIC_SystemReset();
}

