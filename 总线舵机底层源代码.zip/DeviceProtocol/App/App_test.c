#include "App.h"

#if TEST_MODE

#include "bsp_AS5600.h"
#include "Protocol.h"


void App_test_init() {
	DM_init();
	Protocol_init();
	
	LED_INIT();
	
	AS5600_init();
	
	
}

void App_test_angle_scan_task() {
	static uint8_t i = 0;
	
	float angle = bsp_as5600_get_angle();
	printf("angle: %f\r\n", angle);
}

void App_test_flash_task() {
	static uint8_t i = 0;
	static uint8_t cnt = 0;
//	if(i == 0) {
//		uint16_t id = GD25Qxx_readID();
//		printf("ID: 0x%04X\r\n", id);
//	} else if(i == 1) {	
//		uint8_t buff[16];
//		sprintf((char*)buff, "hello %d", cnt++);
//		
//		printf("write: %s\r\n", buff);
//		GD25Qxx_write(buff, 0x00, 7);
//	} else if(i == 2) {	
//		uint8_t buff[16];
//		GD25Qxx_read(buff, 0x00, 7);
//		buff[7] = '\0';
//		printf("read: %s\r\n", buff);
//	}
//	i++;
//	
//	if(i == 3) {
//		i = 1;
//	}
}


void lib_usart0_on_recv(uint8_t *data, uint16_t len) {
	
//	if(data[0] == 0x00) {
//		// read
//		LOG_DEBUG("ID: %d\r\n", g_rws_data.ID);
//		LOG_DEBUG("KP: %d\r\n", g_rws_data.kp);
//		LOG_DEBUG("KI: %d\r\n", g_rws_data.ki);
//		LOG_DEBUG("KD: %d\r\n", g_rws_data.kd);
//	} else if(data[0] == 0x01) {
//		// reload
//		DM_reload();
//	} else if(data[0] == 0x02) {
//		// store
////		DM_store();
//	} else if(data[0] == 0x03) {
//		// write id
//		g_rws_data.ID = data[1];
//		DM_store((uint32_t)&(g_rws_data.ID), 1);
//	} else if(data[0] == 0x04) {
//		// write kp
//		g_rws_data.kp = data[1];
//		DM_store((uint32_t)&(g_rws_data.kp), 1);
//	} else if(data[0] == 0x05) {
//		// write ki
//		g_rws_data.ki = data[1];
//		DM_store((uint32_t)&(g_rws_data.ki), 1);
//	} else if(data[0] == 0x06) {
//		// write kd
//		g_rws_data.kd = data[1];
//		DM_store((uint32_t)&(g_rws_data.kd), 1);
//	}
	
	Protocol_recv_more(data, len);
}

void App_test_parse_task() {
	Protocol_parse();
}


#endif