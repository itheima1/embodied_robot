#ifndef __ADC_CONFIG_H__
#define __ADC_CONFIG_H__


#include "../gpio/lib_gpio.h"
#include "systick.h"


#define USE_LIB_ADC			1


#if USE_LIB_ADC

#define ADC_CHN_REGULAR     0
#define ADC_CHN_INSERT      1

///////////////////// ADC CONFIG ///////////////////
#define ADCx_CK_DIV			RCU_ADCCK_APB2_DIV8
#define ADCx_RESOLUTION     ADC_RESOLUTION_12B
#define ADCx_DATAALIGN      ADC_DATAALIGN_RIGHT

#define ADCx_CHN_TYPE       ADC_CHN_REGULAR
#define ADCx_SAMPLETIME     ADC_SAMPLETIME_480

#define ADCx_CHNS_LEN       5
#define ADCx_CHNS           {                   \
								ADC_CHANNEL_3,  \
								ADC_CHANNEL_16, \
								ADC_CHANNEL_17, \
								ADC_CHANNEL_9, 	\
								ADC_CHANNEL_2, 	\
                            }
							
#define ADCx_SAMPLETIMES	{								\
								ADC_SAMPLETIME_239POINT5,	\
								ADC_SAMPLETIME_239POINT5,	\
								ADC_SAMPLETIME_239POINT5,	\
								ADC_SAMPLETIME_239POINT5,	\
								ADC_SAMPLETIME_239POINT5,	\
							}
                      





#endif


#endif