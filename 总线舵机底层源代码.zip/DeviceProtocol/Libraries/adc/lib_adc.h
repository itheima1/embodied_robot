#ifndef __LIB_ADC0_H__
#define __LIB_ADC0_H__

#include "ADC_config.h"


void lib_adc_init();
void lib_adc_deinit();

uint16_t lib_adc_get(uint8_t chn);


#endif