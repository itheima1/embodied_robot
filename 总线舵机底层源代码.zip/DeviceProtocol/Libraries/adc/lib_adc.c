#include "lib_adc.h"

#if USE_LIB_ADC

#if ADCx_CHN_TYPE == ADC_CHN_REGULAR
#if ADCx_CHNS_LEN > 12
#error "ADC0 channel Routine len must <= 19 "
#endif
#else
#if ADCx_CHNS_LEN > 4
#error "ADC0 channel Insert len must <= 4 "
#endif
#endif

#define GP_CH0      RCU_GPIOA, GPIOA, GPIO_PIN_0
#define GP_CH1      RCU_GPIOA, GPIOA, GPIO_PIN_1
#define GP_CH2      RCU_GPIOA, GPIOA, GPIO_PIN_2
#define GP_CH3      RCU_GPIOA, GPIOA, GPIO_PIN_3
#define GP_CH4      RCU_GPIOA, GPIOA, GPIO_PIN_4
#define GP_CH5      RCU_GPIOA, GPIOA, GPIO_PIN_5
#define GP_CH6      RCU_GPIOA, GPIOA, GPIO_PIN_6
#define GP_CH7      RCU_GPIOA, GPIOA, GPIO_PIN_7
#define GP_CH8      RCU_GPIOB, GPIOB, GPIO_PIN_0
#define GP_CH9      RCU_GPIOB, GPIOB, GPIO_PIN_1


#if ADCx_CHN_TYPE == ADC_CHN_ROUTINE
static uint16_t adcx_result[ADCx_CHNS_LEN] = {0};
static void ADCx_DMA_config() {
    uint32_t dmax_rcu 	= RCU_DMA;
    uint32_t dmax_ch 	= DMA_CH0;

    /**************** DMA p2m *******************/
    // ʱ��
    rcu_periph_clock_enable(dmax_rcu);
    // ����dma
    dma_deinit(dmax_ch);

    //////// dma ����
    dma_parameter_struct dps;
    dma_struct_para_init(&dps);
    // ����
    dps.direction 		= DMA_PERIPHERAL_TO_MEMORY;
	 // ����: src
    dps.periph_addr 	= (uint32_t)(&ADC_RDATA);
    dps.periph_inc 		= DMA_PERIPH_INCREASE_DISABLE;
	dps.periph_width 	= DMA_PERIPHERAL_WIDTH_16BIT;
	
   // �ڴ�: dst
    dps.memory_addr 	= (uint32_t)(adcx_result);
    dps.memory_inc 		= DMA_MEMORY_INCREASE_ENABLE;
	dps.memory_width	= DMA_MEMORY_WIDTH_16BIT;
   
    // ���ݳ���
    dps.number 			= ADCx_CHNS_LEN;
	
    // �������ȼ�
    dps.priority = DMA_PRIORITY_ULTRA_HIGH;
    
	dma_init(dmax_ch, &dps);

    dma_circulation_enable(dmax_ch);

    // Ĭ�Ͽ�������
    dma_flag_clear(dmax_ch, DMA_FLAG_FTF);
    dma_channel_enable(dmax_ch);
}
#endif


void lib_adc_init() {
    uint8_t adcx_chns[] 	= ADCx_CHNS;
	uint32_t adcx_samples[] = ADCx_SAMPLETIMES;
    uint8_t adcx_chns_len 	= ADCx_CHNS_LEN;
	
    
    /******************** GPIO config *********************/
    for(uint8_t i = 0; i < adcx_chns_len; i++) {
        if(adcx_chns[i] == ADC_CHANNEL_0) {
            lib_io_analog(GP_CH0);
        } else if(adcx_chns[i] == ADC_CHANNEL_1) {
            lib_io_analog(GP_CH1);
        } else if(adcx_chns[i] == ADC_CHANNEL_2) {
            lib_io_analog(GP_CH2);
        } else if(adcx_chns[i] == ADC_CHANNEL_3) {
            lib_io_analog(GP_CH3);
        } else if(adcx_chns[i] == ADC_CHANNEL_4) {
            lib_io_analog(GP_CH4);
        } else if(adcx_chns[i] == ADC_CHANNEL_5) {
            lib_io_analog(GP_CH5);
        } else if(adcx_chns[i] == ADC_CHANNEL_6) {
            lib_io_analog(GP_CH6);
        } else if(adcx_chns[i] == ADC_CHANNEL_7) {
            lib_io_analog(GP_CH7);
        } else if(adcx_chns[i] == ADC_CHANNEL_8) {
            lib_io_analog(GP_CH8);
        } else if(adcx_chns[i] == ADC_CHANNEL_9) {
            lib_io_analog(GP_CH9);
        }
    }

    /******************** ADC config **********************/
	adc_deinit();
    // ����ʱ��
    rcu_periph_clock_enable(RCU_ADC);
	/* config ADC clock */
    rcu_adc_clock_config(ADCx_CK_DIV);
    
    ////////// ��������
    adc_resolution_config(ADCx_RESOLUTION); // �ֱ���
    adc_data_alignment_config(ADCx_DATAALIGN);// ���ݶ���

	adc_tempsensor_vrefint_enable();
    //////////// ��������
#if ADCx_CHN_TYPE == ADC_CHN_REGULAR
    adc_channel_length_config(ADC_REGULAR_CHANNEL, adcx_chns_len); // ����
    
    for(uint8_t i = 0; i < adcx_chns_len; i++) {
        adc_regular_channel_config(i, adcx_chns[i], adcx_samples[i]);
        
        if(adcx_chns[i] >= ADC_CHANNEL_16) {
			adc_tempsensor_vrefint_enable();
        }
    }
#else    
    adc_channel_length_config(ADCx, ADC_INSERTED_CHANNEL, adcx_chns_len); // ����
    
    for(uint8_t i = 0; i < adcx_chns_len; i++) {
        adc_inserted_channel_config(ADCx, i, adcx_chns[i], ADCx_SAMPLETIME);
        
        if(adcx_chns[i] >= ADC_CHANNEL_16) {
            adc_channel_16_to_18(ADC_TEMP_VREF_CHANNEL_SWITCH, ENABLE);
            adc_channel_16_to_18(ADC_VBAT_CHANNEL_SWITCH, ENABLE);
        }
    }
#endif    
	
    /////////// ģʽ����
    adc_special_function_config(ADC_SCAN_MODE, ENABLE);// ȡ��ɨ��ģʽ
    adc_special_function_config(ADC_CONTINUOUS_MODE, ENABLE);//ȡ������ģʽ

#if ADCx_CHN_TYPE == ADC_CHN_REGULAR   
	adc_external_trigger_source_config(ADC_REGULAR_CHANNEL, ADC_EXTTRIG_REGULAR_NONE); 
    adc_external_trigger_config(ADC_REGULAR_CHANNEL, ENABLE);
    /// DMA 
    adc_dma_mode_enable();
#else
    adc_special_function_config(ADCx, ADC_INSERTED_CHANNEL_AUTO, ENABLE);//ȡ������ģʽ
#endif

    // ��ADC
    adc_enable();
    delay_1ms(100);

    // У׼ADC
    adc_calibration_enable();
    delay_1ms(100);
    
    
    ADCx_DMA_config();
    
#if ADCx_CHN_TYPE == ADC_CHN_REGULAR    
    // ��������
    adc_software_trigger_enable(ADC_REGULAR_CHANNEL);
#elif
    // ��������
    adc_software_trigger_enable(ADCx, ADC_INSERTED_CHANNEL);
#endif
}

void lib_adc_deinit() {
	adc_deinit();
    // ����ʱ��
    rcu_periph_clock_disable(RCU_ADC);
	
	uint32_t dmax_rcu 	= RCU_DMA;
    uint32_t dmax_ch 	= DMA_CH0;
	dma_channel_disable(dmax_ch);
	dma_deinit(dmax_ch);
	rcu_periph_clock_disable(dmax_rcu);
}


uint16_t lib_adc_get(uint8_t chn) {
#if ADCx_CHN_TYPE == ADC_CHN_REGULAR  
    uint8_t idx = 100;
    uint8_t adcx_chns[] = ADCx_CHNS;
    uint8_t adcx_chns_len = ADCx_CHNS_LEN;
    for(uint8_t i = 0; i < adcx_chns_len; i++) {
        if(adcx_chns[i] == chn) {
            idx = i;
			break;
        }
    }
    if(idx != 100) return adcx_result[idx];
    return 0;
#endif    
    
    return 0;
}


#endif