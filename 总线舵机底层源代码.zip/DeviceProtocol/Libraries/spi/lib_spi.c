#include "lib_spi.h"



void lib_spi_init() {
#if USE_LIB_SPI_0
	lib_spi0_init();
#endif

#if USE_LIB_SPI_1
	lib_spi1_init();
#endif	
}

void lib_spi_deinit() {
#if USE_LIB_SPI_0
	lib_spi0_deinit();
#endif

#if USE_LIB_SPI_1
	lib_spi1_deinit();
#endif
}
