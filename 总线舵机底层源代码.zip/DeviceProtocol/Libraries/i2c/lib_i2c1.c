#include "lib_i2c1.h"

#if USE_LIB_I2C_1
#include "stdlib.h"
#include "../common/fifo_list.h"
#include "string.h"

#define __I2Cx				I2C1
#define __I2Cx_RCU			RCU_I2C1
#define __I2Cx_SOFT			I2C1_SOFT

#define __I2Cx_SCL_RCU		I2C1_SCL_RCU
#define __I2Cx_SCL_PORT		I2C1_SCL_PORT
#define __I2Cx_SCL_PIN		I2C1_SCL_PIN
#define __I2Cx_SCL_AF		I2C1_SCL_AF
#define __I2Cx_SDA_RCU		I2C1_SDA_RCU
#define __I2Cx_SDA_PORT		I2C1_SDA_PORT
#define __I2Cx_SDA_PIN		I2C1_SDA_PIN
#define __I2Cx_SDA_AF		I2C1_SDA_AF

#define __I2Cx_SPEED			I2C1_SPEED
#define __I2Cx_ENABLE_ASYNC		I2C1_ENABLE_ASYNC
#define __I2Cx_ASYNC_MAX_LEN	I2C1_ASYNC_MAX_LEN

#define __I2Cx_IRQ_ENABLE	I2C1_IRQ_ENABLE
#define __I2Cx_EV_IRQn		I2C1_EV_IRQn
#define __I2Cx_ER_IRQn		I2C1_ER_IRQn
#define __I2Cx_EV_IRQn_NVIC	I2C1_EV_IRQn_NVIC
#define __I2Cx_ER_IRQn		I2C1_ER_IRQn
#define __I2Cx_ER_IRQn_NVIC	I2C1_ER_IRQn_NVIC

#define __I2Cx_FUNC_INIT	lib_i2c1_init
#define	__I2Cx_FUNC_DEINIT	lib_i2c1_deinit
#define __I2Cx_FUNC_LOOP	lib_i2c1_loop
#define __I2Cx_FUNC_WRITE	lib_i2c1_write_sync
#define __I2Cx_FUNC_WRITE2	lib_i2c1_write2_sync
#define __I2Cx_FUNC_READ	lib_i2c1_read_sync
#define __I2Cx_FUNC_WR_IRQ	lib_i2c1_irq_write
#define __I2Cx_FUNC_RD_IRQ	lib_i2c1_irq_read

#define __I2Cx_EVEN_IRQ		i2c1_event_irq_handler
#define __I2Cx_ERROR_IRQ	i2c1_error_irq_handler


#if __I2Cx_ENABLE_ASYNC
static FIFO_List list;
static uint8_t state = 0;//״̬
static uint8_t rw_len = 0;
#endif

#if __I2Cx_SOFT

#endif


void __I2Cx_FUNC_INIT() {
#if __I2Cx_SOFT

#else
    /****************** GPIO config **********************/
    lib_io_af_od_pu(__I2Cx_SCL_RCU, __I2Cx_SCL_PORT, __I2Cx_SCL_PIN, __I2Cx_SCL_AF);
    lib_io_af_od_pu(__I2Cx_SDA_RCU, __I2Cx_SDA_PORT, __I2Cx_SDA_PIN, __I2Cx_SDA_AF);

    /****************** I2C config  **********************/
    i2c_deinit(__I2Cx);
    // ʱ������
    rcu_periph_clock_enable(__I2Cx_RCU);
    // I2C��������
    i2c_clock_config(__I2Cx, __I2Cx_SPEED, I2C_DTCY_2);

    // ʹ��i2c
    i2c_mode_addr_config(__I2Cx, I2C_I2CMODE_ENABLE, I2C_ADDFORMAT_7BITS, 0x00);
    i2c_enable(__I2Cx);

    // i2c ack enable
    i2c_ack_config(__I2Cx, I2C_ACK_ENABLE);

#if __I2Cx_IRQ_ENABLE
    nvic_irq_enable(__I2Cx_EV_IRQn, __I2Cx_EV_IRQn_NVIC);
    nvic_irq_enable(__I2Cx_ER_IRQn, __I2Cx_ER_IRQn_NVIC);
#endif
#endif

#if __I2Cx_ENABLE_ASYNC
    FIFO_init(&list);
#endif
}

void __I2Cx_FUNC_DEINIT() {
#if __I2Cx_SOFT


#else
	
#endif
	
#if __I2Cx_ENABLE_ASYNC
    FIFO_free(&list);
#endif
}

void __I2Cx_FUNC_LOOP() {
#if __I2Cx_ENABLE_ASYNC
    if(FIFO_isEmpty(&list)) return;

    I2C_RWData_t* buff = FIFO_element(&list, 0);

#if __I2Cx_SOFT
#else
    static uint16_t wait_cnt = 0;

    if(wait_cnt > 50000) {
        state = 0;
        rw_len = 0;
        FIFO_dequeue(&list);
        if(buff->cb) buff->cb(1, buff->data, buff->len);
        free(buff->data);
        free(buff);
        return;
    }

    ////// start -> waddr -> reg
    if(state == 0) {// ���ã� ���Ϳ�ʼ�ź�
        if(SET == i2c_flag_get(__I2Cx, I2C_FLAG_I2CBSY)) {
            // æ���ȴ�
            wait_cnt++;
        } else {
            // ��æ����һ��
            wait_cnt = 0;
            state = 1; // start �ź�
        }
    } else if(state == 1) { // start
        i2c_start_on_bus(__I2Cx);
        state = 2;
    } else if(state == 2) { // wait start send finish
        if(RESET == i2c_flag_get(__I2Cx, I2C_FLAG_SBSEND)) {
            // æ���ȴ�
            wait_cnt++;
        } else {
            // ��æ����һ��
            wait_cnt = 0;
            state = 3; // �豸��ַ
        }
    } else if(state == 3) { // �豸��ַ
        i2c_master_addressing(__I2Cx, buff->rwaddr, I2C_TRANSMITTER);
        state = 4;
    } else if(state == 4) {
        if(RESET == i2c_flag_get(__I2Cx, I2C_FLAG_ADDSEND)) {
            // æ���ȴ�
            wait_cnt++;
        } else {
            // ��æ����һ��
            wait_cnt = 0;
            i2c_flag_clear(__I2Cx, I2C_FLAG_ADDSEND);
            state = 5; // �Ĵ�����ַ
        }
    } else if(state == 5) { // �Ĵ�����ַ, ��У��
        if(RESET == i2c_flag_get(__I2Cx, I2C_FLAG_TBE)) {
            // æ���ȴ�
            wait_cnt++;
        } else {
            // ��æ����һ��
            wait_cnt = 0;
            state = 6; // �Ĵ�����ַ
        }
    } else if(state == 6) { // �Ĵ�����ַ������
        i2c_data_transmit(__I2Cx, buff->reg);
        state = 7;
    } else if(state == 7) { // �Ĵ�����ַ���������У��
        if(RESET == i2c_flag_get(__I2Cx, I2C_FLAG_BTC)) {
            // æ���ȴ�
            wait_cnt++;
        } else {
            // ��æ����һ��
            wait_cnt = 0;
            state = 8;
        }
    }

    if((buff->rwaddr & 0x01) == 0x00) {
        // write
        if(state == 8) { // ����, ��У��
            if(RESET == i2c_flag_get(__I2Cx, I2C_FLAG_TBE)) {
                // æ���ȴ�
                wait_cnt++;
            } else {
                // ��æ����һ��
                wait_cnt = 0;
                state = 9; // �Ĵ�����ַ
            }
        } else if(state == 9) { // ���ݣ�����
            i2c_data_transmit(__I2Cx, buff->data[rw_len++]);
            state = 10;
        } else if(state == 10) { // ���ݣ��������У��
            if(RESET == i2c_flag_get(__I2Cx, I2C_FLAG_BTC)) {
                // æ���ȴ�
                wait_cnt++;
            } else {
                // ��æ����һ��
                wait_cnt = 0;

                if(rw_len == buff->len) {
                    //�������
                    state = 20;
                } else {
                    // ��������
                    state = 8; // ����
                }
            }
        }
    } else {
        // read
        if(state == 8) { // start
            i2c_start_on_bus(__I2Cx);
            state = 9;
        } else if(state == 9) { // wait start send finish
            if(RESET == i2c_flag_get(__I2Cx, I2C_FLAG_SBSEND)) {
                // æ���ȴ�
                wait_cnt++;
            } else {
                // ��æ����һ��
                wait_cnt = 0;
                state = 10; // �豸��ַ
            }
        } else if(state == 10) { // �豸��ַ
            i2c_master_addressing(__I2Cx, buff->rwaddr, I2C_TRANSMITTER);
            state = 4;
        } else if(state == 11) {
            if(RESET == i2c_flag_get(__I2Cx, I2C_FLAG_ADDSEND)) {
                // æ���ȴ�
                wait_cnt++;
            } else {
                // ��æ����һ��
                wait_cnt = 0;
                i2c_flag_clear(__I2Cx, I2C_FLAG_ADDSEND);
                state = 12; // config ack
            }
        } else if(state == 12) {
            //ack
            i2c_ack_config(__I2Cx, I2C_ACK_ENABLE);
            // ����һ�����ݺ��Զ�����ACK
            i2c_ackpos_config(__I2Cx, I2C_ACKPOS_CURRENT);
            state = 13;
        } else if(state == 13) {
            if(RESET == i2c_flag_get(__I2Cx, I2C_CTL0(__I2Cx) & I2C_CTL0_ACKEN)) {
                wait_cnt++;
            } else {
                // ȷ��ACK������
                wait_cnt = 0;
                state = 14; // recv
            }
        } else if(state == 14) {
            if (rw_len == buff->len - 1) {
                // �ڶ�ȡ���һ���ֽ�֮ǰ������ACK������Ϊ�Զ�NACK
                i2c_ack_config(__I2Cx, I2C_ACK_DISABLE);
            }
            state = 15;
        } else if(state == 15) {
            // �ȴ����ջ�������Ϊ��
            if(RESET == i2c_flag_get(__I2Cx, I2C_FLAG_RBNE)) {
                wait_cnt++;
            } else {
                // ȷ��ACK������
                wait_cnt = 0;
                state = 16; // recv
            }
        } else if(state == 16) {
            buff->data[rw_len++] = i2c_data_receive(__I2Cx);
			
			if(rw_len == buff->len) {
				// �������
				state = 20;
			} else {
				// ��������
				state = 14;
			}
        }
    }
	//// stop
    if(state == 20) {
        i2c_stop_on_bus(__I2Cx);
        state = 21;
    } else if(state == 21) {
        if(SET == i2c_flag_get(__I2Cx, I2C_CTL0(__I2Cx) & I2C_CTL0_STOP)) {
            wait_cnt++;
        } else {
            // ���
            state = 0;
            rw_len = 0;
            FIFO_dequeue(&list);
            if(buff->cb) buff->cb(0, buff->data, buff->len);
            free(buff->data);
            free(buff);
        }
    }
#endif

#endif
}

uint8_t __I2Cx_FUNC_WRITE(uint8_t addr, uint8_t reg, uint8_t* data, uint16_t len) {
    uint8_t waddr = addr << 1;
#if __I2Cx_SOFT

#else
    /************* start ***********************/
    // �ȴ�I2C����
    if(I2C_waitn(__I2Cx, I2C_FLAG_I2CBSY)) return 1;
    // start
    i2c_start_on_bus(__I2Cx);
    // �ȴ�I2C���豸�ɹ�������ʼ�ź�
    if(I2C_wait(__I2Cx, I2C_FLAG_SBSEND)) return 2;

    /************* device address **************/
    // �����豸��ַ
    i2c_master_addressing(__I2Cx, waddr, I2C_TRANSMITTER);
    // �ȴ���ַ�������
    if(I2C_wait(__I2Cx, I2C_FLAG_ADDSEND)) return 3;
    i2c_flag_clear(__I2Cx, I2C_FLAG_ADDSEND);

    /************ register address ************/
    // �Ĵ�����ַ
    // �ȴ��������ݻ�����Ϊ��
    if(I2C_wait(__I2Cx, I2C_FLAG_TBE)) return 4;

    // ��������
    i2c_data_transmit(__I2Cx, reg);

    // �ȴ����ݷ������
    if(I2C_wait(__I2Cx, I2C_FLAG_BTC)) return 5;

    /***************** data ******************/
    // ��������
    for(uint16_t i = 0; i < len; i++) {
        uint8_t d = data[i];

        // �ȴ��������ݻ�����Ϊ��
        if(I2C_wait(__I2Cx, I2C_FLAG_TBE)) return 6;

        // ��������
        i2c_data_transmit(__I2Cx, d);

        // �ȴ����ݷ������
        if(I2C_wait(__I2Cx, I2C_FLAG_BTC)) return 7;
    }

    /***************** stop ********************/
    // stop
    i2c_stop_on_bus(__I2Cx);
    if(I2C_waitn(__I2Cx, I2C_CTL0(__I2Cx) & I2C_CTL0_STOP)) return 8;
#endif

    return 0;
}

uint8_t __I2Cx_FUNC_WRITE2(uint8_t addr, uint8_t reg, uint8_t* data, uint8_t offset, uint16_t len) {
    uint8_t waddr = addr << 1;
#if __I2Cx_SOFT

#else
    /************* start ***********************/
    // �ȴ�I2C����
    if(I2C_waitn(__I2Cx, I2C_FLAG_I2CBSY)) return 1;
    // start
    i2c_start_on_bus(__I2Cx);
    // �ȴ�I2C���豸�ɹ�������ʼ�ź�
    if(I2C_wait(__I2Cx, I2C_FLAG_SBSEND)) return 2;

    /************* device address **************/
    // �����豸��ַ
    i2c_master_addressing(__I2Cx, waddr, I2C_TRANSMITTER);
    // �ȴ���ַ�������
    if(I2C_wait(__I2Cx, I2C_FLAG_ADDSEND)) return 3;
    i2c_flag_clear(__I2Cx, I2C_FLAG_ADDSEND);

    /************ register address ************/
    // �Ĵ�����ַ
    // �ȴ��������ݻ�����Ϊ��
    if(I2C_wait(__I2Cx, I2C_FLAG_TBE)) return 4;

    // ��������
    i2c_data_transmit(__I2Cx, reg);

    // �ȴ����ݷ������
    if(I2C_wait(__I2Cx, I2C_FLAG_BTC)) return 5;

    /***************** data ******************/
    // ��������
    for(uint16_t i = 0; i < len; i++) {
        uint8_t d = data[i * offset];

        // �ȴ��������ݻ�����Ϊ��
        if(I2C_wait(__I2Cx, I2C_FLAG_TBE)) return 6;

        // ��������
        i2c_data_transmit(__I2Cx, d);

        // �ȴ����ݷ������
        if(I2C_wait(__I2Cx, I2C_FLAG_BTC)) return 7;
    }

    /***************** stop ********************/
    // stop
    i2c_stop_on_bus(__I2Cx);
    if(I2C_waitn(__I2Cx, I2C_CTL0(__I2Cx) & I2C_CTL0_STOP)) return 8;
#endif

    return 0;
}

uint8_t __I2Cx_FUNC_READ(uint8_t addr, uint8_t reg, uint8_t* data, uint16_t len) {
    uint8_t waddr = addr << 1;
    uint8_t raddr = (addr << 1) | 0x01;

#if __I2Cx_SOFT
#else
    /************* start ***********************/
    // �ȴ�I2C����
    if(I2C_waitn(__I2Cx, I2C_FLAG_I2CBSY)) return 1;
    // start
    i2c_start_on_bus(__I2Cx);
    // �ȴ�I2C���豸�ɹ�������ʼ�ź�
    if(I2C_wait(__I2Cx, I2C_FLAG_SBSEND)) return 2;

    /************* device address **************/
    // �����豸��ַ
    i2c_master_addressing(__I2Cx, waddr, I2C_TRANSMITTER);
    // �ȴ���ַ�������
    if(I2C_wait(__I2Cx, I2C_FLAG_ADDSEND)) return 3;
    i2c_flag_clear(__I2Cx, I2C_FLAG_ADDSEND);

    /************ register address ************/
    // �Ĵ�����ַ
    // �ȴ��������ݻ�����Ϊ��
    if(I2C_wait(__I2Cx, I2C_FLAG_TBE)) return 4;

    // ��������
    i2c_data_transmit(__I2Cx, reg);

    // �ȴ����ݷ������
    if(I2C_wait(__I2Cx, I2C_FLAG_BTC)) return 5;

    /************* start ***********************/
    i2c_start_on_bus(__I2Cx);
    // �ȴ�I2C���豸�ɹ�������ʼ�ź�
    if(I2C_wait(__I2Cx, I2C_FLAG_SBSEND)) return 2;

    /************* device address **************/
    // ���ʹ��豸����ַ
    i2c_master_addressing(__I2Cx, raddr, I2C_RECEIVER);
    if(I2C_wait(__I2Cx, I2C_FLAG_ADDSEND)) return 8;
    i2c_flag_clear(__I2Cx, I2C_FLAG_ADDSEND);

    /**************** ��������data *************/
    //ack
    i2c_ack_config(__I2Cx, I2C_ACK_ENABLE);
    // ����һ�����ݺ��Զ�����ACK
    i2c_ackpos_config(__I2Cx, I2C_ACKPOS_CURRENT);
    // ȷ��ACK������
    if(I2C_wait(__I2Cx, I2C_CTL0(__I2Cx) & I2C_CTL0_ACKEN)) return 9;

    for (uint16_t i = 0; i < len; i++) {
        if (i == len - 1) {
            // �ڶ�ȡ���һ���ֽ�֮ǰ������ACK������Ϊ�Զ�NACK
            i2c_ack_config(__I2Cx, I2C_ACK_DISABLE);
        }

        // �ȴ����ջ�������Ϊ��
        if(I2C_wait(__I2Cx, I2C_FLAG_RBNE)) return 10;

        data[i] = i2c_data_receive(__I2Cx);
    }

    /***************** stop ********************/
    // stop
    i2c_stop_on_bus(__I2Cx);
    if(I2C_waitn(__I2Cx, I2C_CTL0(__I2Cx) & I2C_CTL0_STOP)) return 11;

#endif
    return 0;
}


#if __I2Cx_ENABLE_ASYNC
uint8_t lib_i2c0_write_async(uint8_t addr, uint8_t reg, uint8_t* data, uint16_t len, I2C_RW_Callback cb) {
    if(FIFO_length(&list) >= __I2Cx_ASYNC_MAX_LEN) return 1;

    I2C_RWData_t *buff = malloc(sizeof(I2C_RWData_t));

    buff->rwaddr 	= (addr << 1); // waddr
    buff->reg 		= reg;
    buff->len		= len;
    buff->data		= malloc(sizeof(uint8_t) * len);
    memcpy(buff->data, data, len);
    buff->cb		= cb;

    FIFO_enqueue(&list, buff);

    return 0;
}

uint8_t lib_i2c0_read_async(uint8_t addr, uint8_t reg, uint16_t len, I2C_RW_Callback cb) {
    if(FIFO_length(&list) >= __I2Cx_ASYNC_MAX_LEN) return 1;

    I2C_RWData_t *buff = malloc(sizeof(I2C_RWData_t));

    buff->rwaddr 	= (addr << 1) | 0x01; // raddr
    buff->reg 		= reg;
    buff->len		= len;
    buff->data		= malloc(sizeof(uint8_t) * len);
    buff->cb		= cb;

    FIFO_enqueue(&list, buff);

    return 0;
}
#endif



#if I2C0_IRQ_ENABLE

uint8_t __I2Cx_FUNC_WR_IRQ(I2C_IRQ_Data_t dat) {
    irq_data = &dat;

    /* enable the I2C interrupt */
    i2c_interrupt_enable(__I2Cx, I2C_INT_ERR);
    i2c_interrupt_enable(__I2Cx, I2C_INT_EV);
    i2c_interrupt_enable(__I2Cx, I2C_INT_BUF);

    /************* start ***********************/
    // �ȴ�I2C����
    if(I2C_waitn(__I2Cx, I2C_FLAG_I2CBSY)) return 1;
    // start
    i2c_start_on_bus(__I2Cx);

    return 0;
}

uint8_t __I2Cx_FUNC_RD_IRQ(I2C_IRQ_Data_t dat) {
    return 0;
}



void __I2Cx_EVEN_IRQ(void)
{
    if(i2c_interrupt_flag_get(__I2Cx, I2C_INT_FLAG_SBSEND)) {
        /* send slave address */
        i2c_master_addressing(__I2Cx, (irq_data->addr) << 1, I2C_TRANSMITTER);
    } else if(i2c_interrupt_flag_get(__I2Cx, I2C_INT_FLAG_ADDSEND)) {
        /*clear ADDSEND bit */
        i2c_interrupt_flag_clear(__I2Cx, I2C_INT_FLAG_ADDSEND);
    } else if(i2c_interrupt_flag_get(__I2Cx, I2C_INT_FLAG_TBE)) {
        if(irq_data->tx_len > 0) {
            /* the master sends a data byte */
            i2c_data_transmit(__I2Cx, *irq_data->tx_buffer++);
            irq_data->tx_len--;
        } else {
            /* the master sends a stop condition to I2C bus */
            i2c_stop_on_bus(__I2Cx);
            /* disable the I2C0 interrupt */
            i2c_interrupt_disable(__I2Cx, I2C_INT_ERR);
            i2c_interrupt_disable(__I2Cx, I2C_INT_BUF);
            i2c_interrupt_disable(__I2Cx, I2C_INT_EV);

            // success
            irq_data->cb(0);
        }
    }
}

void __I2Cx_ERROR_IRQ(void)
{
    /* no acknowledge received */
    if(i2c_interrupt_flag_get(I2C0, I2C_INT_FLAG_AERR)) {
        i2c_interrupt_flag_clear(I2C0, I2C_INT_FLAG_AERR);
    }

    /* SMBus alert */
    if(i2c_interrupt_flag_get(I2C0, I2C_INT_FLAG_SMBALT)) {
        i2c_interrupt_flag_clear(I2C0, I2C_INT_FLAG_SMBALT);
    }

    /* bus timeout in SMBus mode */
    if(i2c_interrupt_flag_get(I2C0, I2C_INT_FLAG_SMBTO)) {
        i2c_interrupt_flag_clear(I2C0, I2C_INT_FLAG_SMBTO);
    }

    /* over-run or under-run when SCL stretch is disabled */
    if(i2c_interrupt_flag_get(I2C0, I2C_INT_FLAG_OUERR)) {
        i2c_interrupt_flag_clear(I2C0, I2C_INT_FLAG_OUERR);
    }

    /* arbitration lost */
    if(i2c_interrupt_flag_get(I2C0, I2C_INT_FLAG_LOSTARB)) {
        i2c_interrupt_flag_clear(I2C0, I2C_INT_FLAG_LOSTARB);
    }

    /* bus error */
    if(i2c_interrupt_flag_get(I2C0, I2C_INT_FLAG_BERR)) {
        i2c_interrupt_flag_clear(I2C0, I2C_INT_FLAG_BERR);
    }

    /* CRC value doesn't match */
    if(i2c_interrupt_flag_get(I2C0, I2C_INT_FLAG_PECERR)) {
        i2c_interrupt_flag_clear(I2C0, I2C_INT_FLAG_PECERR);
    }

    /* disable the I2C0 interrupt */
    i2c_interrupt_disable(I2C0, I2C_INT_ERR);
    i2c_interrupt_disable(I2C0, I2C_INT_BUF);
    i2c_interrupt_disable(I2C0, I2C_INT_EV);
}



#endif


#endif


