#include "lib_i2c.h"


void lib_i2c_init() {
#if USE_LIB_I2C_0
	lib_i2c0_init();
#endif
#if USE_LIB_I2C_1
	lib_i2c1_init();
#endif	
}

void lib_i2c_deinit() {
#if USE_LIB_I2C_0
	lib_i2c0_deinit();
#endif
#if USE_LIB_I2C_1
	lib_i2c1_deinit();
#endif
}

void lib_i2c_loop() {
#if USE_LIB_I2C_0
	lib_i2c0_loop();
#endif
#if USE_LIB_I2C_1
	lib_i2c1_loop();
#endif	
}